"""
Created on Wed April 6 2022

@author: Irene garcía-González


Place all '_All_Objects_parameters.csv' files from FIJI analysis in a folder. Within that folder create subfolder with
name/reference of each sample (retina/mouse). Once all data files are compiled, this name/reference will be located in
a novel variable.

"""


import os # OS module provides functions for interacting with the operating system
from tkinter import filedialog #tkinter is the standard python interface to the GUI toolkit
import pandas as pd #pandas is a python library used to analyse data


path=filedialog.askdirectory(title = 'Choose the FOLDER containing the CSV files') 
path_save=filedialog.askdirectory(title = 'Choose the FOLDER where the summary CSV files will be saved')
all_folders = os.listdir(path)



final=pd.DataFrame()
all_folders2=[]
names=[]
for fld in all_folders: #opens first folder containing control and mutant folders
    
    all_folders2.append(path+'/'+fld)
    
for fld2 in all_folders2: #Open each folder Ctrl or mut
    all_files=[]
    all_files = os.listdir(fld2)  #prepares a list with all the files in that folder
    for file in all_files:
        all_files2=[]
        all_files2.append(fld2 + '/' + file) #generates a list with the adress of each file
        for fl in all_files2:
            print(fl)
            if (fl.find('All_Objects_Parameters') != -1): 
                    name=os.path.basename(fl)
                    tag=os.path.dirname(fl)
                    tagt=os.path.basename(tag)
                    file=open(fl)
                    table = pd.read_csv(fl, delimiter = "\t")
                    allcol=pd.DataFrame()
                    allcol=table.iloc[:,:]
                    n=len(allcol)
                    names=''
                    names=[name]*n
                    sample=''
                    sample=[tagt]*n
                    allcol["Image"]=names
                    allcol['Sample_Type']=sample
                    
                    final=pd.concat([final,allcol], axis=0)

final.to_csv(path_save + '/'+'All_data_compilation' , index=False)