









FilterLowExpressionGenes_onlytable <- function(seurat_obj, filt_th = 0.75, min_cells=10) {
  library(moments)
  # This function filters low-expression genes from a Seurat object based on skewness of expression levels. 
 
   #The skewness of a gene in single-cell data measures the asymmetry of the distribution of its expression
  #values across the cells. It provides insights into the pattern of gene expression, helping to identify 
  #genes that are expressed in a small subset of cells (highly skewed distribution) versus those with more 
  #uniform expression.
  
  # It calculates the skewness of non-zero expression values for each gene and filters out genes where the  
  # skewness exceeds a given threshold (`filt_th`), provided the gene is expressed in at least `min_cells`.  
  # The function returns a list containing:  
  # 1. A data frame (`gene_per`) with gene-level statistics including skewness values, rejection status, and the  
  #    number of cells expressing each gene.  
  # 2. A vector (`genes_filtered`) of genes that pass the filtering criteria.  
  
  # Extract normalized expression data
  dense_data <- as.matrix(seurat_obj@assays[["RNA"]]@layers[["data"]])
  rownames(dense_data) <- rownames(seurat_obj)
  # Calculate the first quartile (25th percentile) for each gene
  sk <- apply(dense_data, 1, function(x) skewness(x[x > 0], na.rm = TRUE))
  sk[is.na(sk)]<-0
  names(sk) <- rownames(dense_data)
  
  # Identify genes where >=75% of expressing cells have expression within the first quartile
  # Initialize a vector to store the results
  low_expression_filter <- logical(nrow(dense_data))
  gene_percentage <- data.frame(
    gene = rownames(dense_data),      # Column for gene names
    skewness_values = numeric(nrow(dense_data)),
    reject_gene= logical(nrow(dense_data)),
    num_expres= numeric(nrow(dense_data)))
  # Iterate over each row (gene)
  for (i in seq_len(nrow(dense_data))) {
    # Get the current gene expression values
    x <- dense_data[i, ]
    # Get the current gene name
    positive_values <- x[x > 0]
    
    # Number of cells expressing the gene
    num_expressing_cells <- sum(x > 0)
    
    # Calculate the filtering condition
    if (num_expressing_cells > min_cells) {  # Avoid division by zero
      gene_percentage$skewness_values[i] <- sk[i]
      gene_percentage$reject_gene[i]<-sk[i] >= filt_th
      gene_percentage$num_expres[i] <- num_expressing_cells
      low_expression_filter[i] <- sk[i] >= filt_th
      
    } else {
      gene_percentage$skewness_values[i] <- sk[i]
      gene_percentage$reject_gene[i]<- FALSE 
      gene_percentage$num_expres[i] <- num_expressing_cells
      low_expression_filter[i] <- FALSE  # If no cells express the gene, it is not low-expression filtered
    }
  }
  
  
  # Return the modified Seurat object
  # Filter genes: Keep genes that do NOT meet the low-expression criterion
  genes_to_keep <- !low_expression_filter
  all.genes <- rownames(seurat_obj)
  all.genes_filt <- all.genes[genes_to_keep]
  
  return(list(
    gene_per =gene_percentage,
    genes_filtered = all.genes_filt
    ))
  }


