

library(Seurat)
library(ggplot2)
library(dplyr)

plot_top_markers_dotplot <- function(degs_list, rds_object, colors_palette, top_n = 10, group_by = "celltypes",extra_title='',
                                     palette = NULL, expression_weigth=0.3,logfc_weigth=0.7,pdf_name='' ) {
  color_gradient_pallete <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")
  # Step 1: Select top genes per cluster
  # Remove duplicates by gene (optional)
  degs_list <- degs_list[!duplicated(degs_list$gene), ]
  
  top_genes <- degs_list %>%
    group_by(cluster) %>%
    mutate(score = logfc_weigth * avg_log2FC + expression_weigth * pct.1) %>%
    slice_max(score, n = top_n, with_ties = FALSE)

  
  print(top_genes)
  t<-unique(top_genes$cluster)
  number_clusters <-sum(table(t))
  
  gene_counts<-dplyr::count(ungroup(top_genes), cluster) %>% pull(n)
  gene_positions <- cumsum(gene_counts)
  cluster_separations <- gene_positions + 0.5 
  print(cluster_separations)
  # Step 2: Create cluster box info
  cluster_boxes <- data.frame(
    xmin = c(0.5, cluster_separations[-length(cluster_separations)]),
    xmax = cluster_separations,
    ymin = Inf,
    ymax = number_clusters+0.3,
    fill = colors_palette
  )
  
  # Step 3: Create DotPlot
  
  p<-DotPlot(rds_object, features = top_genes$gene, group.by = group_by, col.min = 0, dot.scale = 5)&
    scale_colour_gradientn(colours = color_gradient_pallete)&
    ggtitle(paste0('Top gene markers per cluster ', extra_title), subtitle = paste0('Top ', top_n,' AvgLogFC'))&
    theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic', size =9), axis.title = element_blank())&
    geom_rect(data = cluster_boxes, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill), 
              alpha =1, inherit.aes = FALSE) &
    geom_vline(xintercept = cluster_separations, linetype = "dashed", color = "black", size = 0.8)&
    scale_fill_identity()
  cairo_pdf(filename = paste0('Dotplot_CelltypeMarkers_', pdf_name, '.pdf'), width = 20, height = 5)
  print(p)
  dev.off()
  
 
  
  return(p)
}


plot_top_markers_dotplot(rds_object = adult_kidney, degs_list = kidney_degs,group_by = 'celltypes2',extra_title = 'Kidney',
                         colors_palette = adult_kidney_cols, top_n = 15)
