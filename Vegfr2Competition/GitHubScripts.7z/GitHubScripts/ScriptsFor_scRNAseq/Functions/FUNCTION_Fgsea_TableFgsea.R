library(Seurat)
library(fgsea)
library(msigdbr)
library(tidyverse)
library(readr)


FGSEA_Table_Plot<- function(degs_table, min_size = 3, extra_name='',topn=10,cat='H', subc=F, title_table='fGSEA results', filter_pval=F) {
  # This function performs a Gene Set Enrichment Analysis (GSEA) using the fgsea algorithm on a differential expression  
  # results table. It generates a visual summary of the enrichment analysis as a GSEA table, saves the results in a  
  # PDF file, and outputs the full results table in a CSV file.  
  
  # Parameters:  
  # - degs_table: A data frame containing differential expression results, which must include:  
  #   - `avg_log2FC`: Log2 fold changes for each gene.  
  #   - Row names representing gene symbols.  
  # - min_size: The minimum number of genes required in a gene set for it to be considered in the GSEA (default is 3).  
  # - extra_name: A string to append to output file names, useful for distinguishing results (default is '').  
  # - topn: The number of top upregulated and downregulated pathways to include in the GSEA table visualization (default is 10).  
  
  # Workflow:  
  # 1. **Prepare Data for GSEA:**  
  #    - A named vector of log2 fold changes is created using the `avg_log2FC` column from `degs_table`.  
  #    - Gene symbols are used as the vector names to map genes to pathways.  
  
  # 2. **Load Hallmark Gene Sets:**  
  #    - Hallmark pathways are retrieved using the `msigdbr` package for the species `Mus musculus` (mouse).  
  #    - The gene sets are split into a list where each element corresponds to a pathway and its associated genes.  
  
  # 3. **Run FGSEA Analysis:**  
  #    - The `fgsea` function is used to perform the enrichment analysis, with the `min_size` parameter controlling the  
  #      minimum number of genes in a pathway to include in the analysis.  
  #    - The results are stored in a tidy format (`fgseaResTidy`) and sorted by normalized enrichment score (NES).  
  
  # 4. **Identify Top Pathways:**  
  #    - The top pathways are selected based on NES and adjusted p-value (`padj`).  
  #    - `topn` upregulated and `topn` downregulated pathways are selected for visualization in the GSEA table.  
  
  # 5. **Generate GSEA Table Plot:**  
  #    - The selected pathways are visualized using `plotGseaTable`.  
  #    - The plot shows the enrichment scores, running enrichment score profiles, and the positions of leading-edge genes.  
  #    - The GSEA table is saved to a PDF file named dynamically based on the comparison and `min_size`.  
  
  # 6. **Save Full FGSEA Results:**  
  #    - The complete FGSEA results, including NES, adjusted p-values, and other metrics for all tested pathways, are  
  #      saved to a CSV file for further exploration.  
  
  # Output:  
  # - A PDF file containing the GSEA table for the top pathways is saved to the working directory.  
  # - A CSV file with the full FGSEA results is saved to the working directory.  
  
  # Use Case:  
  # This function is useful for identifying and visualizing the biological pathways most significantly affected in  
  # a differential expression analysis. The combination of visual and tabular outputs allows researchers to prioritize  
  # pathways for further investigation, interpret results in a biological context, and share the findings effectively.  
  set.seed(35)
    # Step 2: Create logFC vector for fgsea
    logfc <- setNames(degs_table$avg_log2FC, degs_table$gene)
    
    # Step 3: Load Hallmark gene sets from msigdbr
    if(subc!=F){
      m_df <- msigdbr(species = "Mus musculus", category =cat, subcategory = subc)  
    }
    else{
    m_df <- msigdbr(species = "Mus musculus", category ='H') # Hallmark pathways
    }
    fgsea_sets <- m_df %>% split(x = .$gene_symbol, f = .$gs_name)
    
    # Step 4: Perform FGSEA analysis
    fgseaRes <- fgsea(fgsea_sets, stats = logfc, minSize = min_size)
    fgseaResTidy <- fgseaRes %>% as_tibble() %>% arrange(desc(NES))
    
    # Step 5: Define pathways for GSEA table
    
    if(filter_pval == T){
      top_pathways_up <-fgseaResTidy[fgseaResTidy$padj<0.05,]
      top_pathways_up <- top_pathways_up %>% filter(NES > 0)  %>%  slice_head(n=topn) %>% pull(pathway)
      top_pathways_down <-fgseaResTidy[fgseaResTidy$padj<0.05,]
      top_pathways_down <-top_pathways_down%>% filter(NES < 0)%>% slice_tail(n=topn)%>% pull(pathway)
      
    }
    else{
      top_pathways_up <- fgseaResTidy %>% filter(NES > 0) %>% slice_head(n=topn) %>% pull(pathway)
      top_pathways_down <- fgseaResTidy %>% filter(NES < 0) %>% slice_tail(n=topn)%>% pull(pathway)
      }
    top_pathways <- c(top_pathways_up, top_pathways_down)
    
    # Step 6: Plot GSEA Table
    title_name <- paste0('FGSEA_Table_comparison_of_', extra_name)
    pdf_filename <- paste0(title_name, '_MinGeneSize_', min_size, '.pdf')
    ln<-length(top_pathways)
    ln<-ln/1.5
    # Save GSEA Table to a PDF
    cairo_pdf(file = pdf_filename, width = 12, height = ln)
    plotGseaTable(fgsea_sets[top_pathways], 
                  stats = logfc, 
                  fgseaRes = fgseaRes, 
                  gseaParam = 0.5)
    dev.off()
    # Add leadingEdge genes and classify as up or down
    fgseaResTidy <- fgseaResTidy %>%
      mutate(
        upregulated_genes = sapply(leadingEdge, function(genes) {
          paste(names(logfc[genes][logfc[genes] > 0]), collapse = ", ")
        }),
        downregulated_genes = sapply(leadingEdge, function(genes) {
          paste(names(logfc[genes][logfc[genes] < 0]), collapse = ", ")
        }),
        label = paste0("p=", signif(padj, 2)) # Format p-values for labels
      )
    
    # Step 7: Save FGSEA results table
    excel_filename <- paste0(title_name, '_MinGeneSize_', min_size, '.csv')
    write_excel_csv(fgseaResTidy, file = excel_filename)
    
    print(paste("FGSEA Table and results saved"))
}


