
library(pheatmap)


generate_heatmap_fromGenesFC_mutiplegroups <- function(gene_list, rds_object, first_var , second_var='r',ident_1, ident_2,order_genes_name=F,pct=0,
                                                       name_pdf='HeatmapLFC',clust_method='ward.D2',plot_values=T, long_factor=7,cr=F, cc=F,w=20, lim_minus=-5, lim_max=5, title='Avg_LogFC') {
  
  
  breaksv<- seq(lim_minus, lim_max, 0.2)
             
  t <- rownames(rds_object)
  gene_list <- intersect(t, gene_list)  # Ensure genes exist in the dataset
  lg <- length(gene_list)
  lg <- lg / long_factor
 
  print(lg)
  print(gene_list)
  
  if (length(gene_list) == 0) {
    stop("No genes in the provided gene list are present in the dataset.")
  }
  
  # Ensure met is a valid metadata column
    if (!first_var %in% colnames(rds_object@meta.data)) {
      stop("The provided metadata variable 'first_var' is not a column in the metadata.")}

    
    if(second_var %in% colnames(rds_object@meta.data)){
    Idents(rds_object) <- second_var  # Set the identities to the metadata variable
    var2 <- levels(Idents(rds_object))  # Get all levels of the metadata variable
    results <- list()  # Initialize an empty list to store results
    for (subgroup in var2) {
      subset_obj <- subset(rds_object, idents = subgroup)
      Idents(subset_obj) <- first_var
      tab <- FindMarkers(subset_obj, ident.1 = ident_1, ident.2 = ident_2, features = gene_list,logfc.threshold =0,min.pct=pct)
      tab$gene <- rownames(tab)
      tab$organ <- as.character(subgroup)
      results[[subgroup]] <- tab
    }
    
    tab <-  bind_rows(results, .id = 'sample') # Combine all results into one table
    }
    else{
      Idents(rds_object)<- first_var
      tab <- FindMarkers(rds_object, ident.1 = ident_1, ident.2 = ident_2, features = gene_list,logfc.threshold =0,min.pct=pct)
      print(tab)
      tab$gene <- rownames(tab)
    }
    if (nrow(tab) == 0) {
      stop("No differentially expressed genes found. Check input groups or gene list.")
    }
  
  # Format the data
  tab <- tab %>% 
    mutate(
      padj_lab = sprintf("p_val=%.2g", p_val_adj),
      logFC_lab = ifelse(p_val_adj < 0.05, sprintf("%.2g*", avg_log2FC), sprintf("%.2g", avg_log2FC))
    )
  
  
  if(order_genes_name == F){
          if(second_var %in% colnames(rds_object@meta.data)){
            tab <- tab%>% group_by(gene) %>% 
               mutate(median_logFC = median(avg_log2FC, na.rm = TRUE)) %>%  # Compute median per gene
               ungroup() %>%
               arrange(desc(median_logFC)) 
            val1<-tab %>% select(gene, sample, avg_log2FC)%>%
              pivot_wider(names_from = gene, values_from = avg_log2FC, values_fill = 0) %>%
              column_to_rownames('sample')
            val2<-tab %>% select(gene, sample, logFC_lab)%>%
              pivot_wider(names_from = gene, values_from = logFC_lab) %>%
              column_to_rownames('sample')
            
          } else{
            print('Using single column heatmap')
            tab<-tab %>% arrange(desc(avg_log2FC))
            val1<-tab %>% select(gene, avg_log2FC)%>%
              pivot_wider(names_from = gene, values_from = avg_log2FC, values_fill = 0) 
            val2<-tab %>% select(gene, logFC_lab)%>%
              pivot_wider(names_from = gene, values_from = logFC_lab) 
          }
  }
  else{
    if(second_var %in% colnames(rds_object@meta.data)){
      tab<-tab %>% arrange(gene)
        val1<-tab %>% select(gene, sample, avg_log2FC)%>%
        pivot_wider(names_from = gene, values_from = avg_log2FC, values_fill = 0) %>%
        column_to_rownames('sample')
      val2<-tab %>% select(gene, sample, logFC_lab)%>%
        pivot_wider(names_from = gene, values_from = logFC_lab) %>%
        column_to_rownames('sample')
    } else{
      tab<-tab %>% arrange(gene)
      print('Using single column heatmap')
      val1<-tab %>% select(gene, avg_log2FC)%>%
        pivot_wider(names_from = gene, values_from = avg_log2FC, values_fill = 0) 
      val2<-tab %>% select(gene, logFC_lab)%>%
        pivot_wider(names_from = gene, values_from = logFC_lab) 
    }
    
    
  }
  print(tab)
  # Generate the plot
 print(val1)
   
   l <- length(breaksv)
   cols <-colorRampPalette(c('#1dbfcf','lightblue', 'white', 'pink', "#DF241F"))(l)
   if(second_var %in% colnames(rds_object@meta.data)){
     if(plot_values == TRUE){
       heatmap_plot <- pheatmap(t(val1), display_numbers = t(val2), color = cols, breaks = breaksv,
                                cluster_rows = cr, cluster_cols = cc, clustering_method = clust_method, 
                                main = title, fontsize = 5)
     } else {
       heatmap_plot <- pheatmap(t(val1), color = cols, breaks = breaksv,
                                cluster_rows = cr, cluster_cols = cc, clustering_method = clust_method, 
                                main = title, fontsize = 5)
     }
   } else {
     if(plot_values == TRUE){  # Ensure consistency here
       heatmap_plot <- pheatmap(t(val1), display_numbers = t(val2), color = cols, breaks = breaksv,
                                cluster_rows = cr, cluster_cols = cc, clustering_method = clust_method, 
                                main = title, fontsize = 5)
     } else {
       heatmap_plot <- pheatmap(t(val1), color = cols, breaks = breaksv,
                                cluster_rows = cr, cluster_cols = cc, clustering_method = clust_method, 
                                main = title, fontsize = 5)
     }
   }
  # Save the plot
  cairo_pdf(file = paste0(name_pdf, '.pdf'), width =w, height = lg)
  print(heatmap_plot)
  dev.off()
  
  return(heatmap_plot)
}


