library(ggplot2)
library(EnhancedVolcano)
library(dplyr)

generate_volcano_plot <- function(fgsea_table, degs_table, gene_list_max5,boxed_tables=F,transparency=0.9, top_n = 10,title_plot='Volcano plot',pathways_hallmarks = 'on',
                                  pval_cutoff = 0.05, logfc_cutoff = 0.5, output_file = "VolcanoPlot.pdf", lim=3.5, pct_min=0.02,logfc_cutoff_line=0.5,
                                  cols=c("#6B4795",'#5D75B2', "#EA634C", "#66B3FF", "#31a583", 'orange4', "#B366FF", "#FF66B3", "#FFCC66", '#3CB17E')) {
  
  
  
  
  degs_allclean <- degs_table[degs_table$pct.2>=pct_min & degs_table$pct.1>=pct_min,] 
  degs_fc_all <- degs_table[degs_table$pct.2>=pct_min & degs_table$pct.1>=pct_min & abs(degs_table$avg_log2FC)>logfc_cutoff,] 
  degs_fc <- degs_table[degs_table$pct.2>=pct_min & degs_table$pct.1>=pct_min & abs(degs_table$avg_log2FC)>logfc_cutoff & degs_table$p_val_adj<pval_cutoff,] 
  degs_p <- degs_table[degs_table$p_val_adj<pval_cutoff & degs_table$pct.2>=pct_min & degs_table$pct.1>=pct_min,]
  
  # Identify top up/downregulated genes
  top_up <- (degs_p %>% top_n(n = top_n, avg_log2FC))$gene
  top_down <- (degs_p %>% top_n(n = top_n, -avg_log2FC))$gene
  
  # Filter genes from FGSEA pathways (assuming rows 46 and 47 are EMT and KRAS pathways)
  first_pathway_name <- fgsea_table[1,1] 
  a<-trimws(unlist(strsplit(fgsea_table[1, 9], ",")))
  a_p <- a[a %in% degs_fc$gene]
  second_pathway_name <- fgsea_table[2,1] 
  a2<-trimws(unlist(strsplit(fgsea_table[2, 9], ",")))
  a2_p <- a2[a2 %in% degs_fc$gene]
  
  last_pathway_name <- fgsea_table[nrow(fgsea_table),1] 
  b<- trimws(unlist(strsplit(fgsea_table[nrow(fgsea_table), 10], ",")))
  b_p <- b[b %in% degs_fc$gene]
  
  last2_pathway_name <- fgsea_table[(nrow(fgsea_table)-1),1] 
  b2<- trimws(unlist(strsplit(fgsea_table[(nrow(fgsea_table)-1), 10], ",")))
  b2_p <- b2[b2 %in% degs_fc$gene]
  
  # Extract genes from user-defined lists
  gene_lists <- vector("list", 5) 
  gene_lists[1:length(gene_list_max5)] <- gene_list_max5
  names(gene_lists)[1:length(gene_list_max5)] <- names(gene_list_max5)
  print(gene_lists)
  
  pathway_genes <- lapply(gene_lists, function(g) g[g %in% degs_fc_all$gene])
  
  # Combine all selected genes

  # Assign colors for categories
if (pathways_hallmarks=='on'){
  selection_genes <- c(a_p,a2_p, b_p, b2_p, unlist(pathway_genes), top_up, top_down)
  degs_allclean <- degs_allclean[!(degs_allclean$gene %in% selection_genes), ] %>%
    rbind(degs_allclean[degs_allclean$gene %in% selection_genes, ])
    col_custom <- ifelse(degs_allclean$gene %in% pathway_genes[[1]],  cols[1],
                       ifelse(degs_allclean$gene %in% pathway_genes[[2]],  cols[2],
                              ifelse(degs_allclean$gene %in% pathway_genes[[3]], cols[3],
                                     ifelse(degs_allclean$gene %in% pathway_genes[[4]], cols[4],
                                            ifelse(degs_allclean$gene %in% pathway_genes[[5]],   cols[5],
                                            ifelse(degs_allclean$gene %in% a_p,  cols[6],
                                                   ifelse(degs_allclean$gene %in% a2_p,  cols[7],   
                                                   ifelse(degs_allclean$gene %in% b_p,   cols[8],
                                                          ifelse(degs_allclean$gene %in% b2_p,   cols[9],
                                                          ifelse(degs_allclean$gene %in% c(top_up, top_down), 'grey1',
                                                                 ifelse(degs_allclean$gene %in% degs_fc$gene, 'black', 'grey')))))))))))   

# Assign category names
names(col_custom)[col_custom ==  cols[1]] <- names(gene_lists[1])
names(col_custom)[col_custom ==  cols[2]] <- names(gene_lists[2])
names(col_custom)[col_custom ==  cols[3]] <- names(gene_lists[3])
names(col_custom)[col_custom ==  cols[4]] <- names(gene_lists[4])
names(col_custom)[col_custom ==  cols[5]] <- names(gene_lists[5])
names(col_custom)[col_custom ==  cols[6]] <- first_pathway_name
names(col_custom)[col_custom ==  cols[7]] <- second_pathway_name
names(col_custom)[col_custom ==  cols[8]] <- last_pathway_name
names(col_custom)[col_custom ==  cols[9]] <- last2_pathway_name
names(col_custom)[col_custom == 'grey1'] <- 'Top up or down'
}
  else{
    selection_genes <- c(unlist(pathway_genes), top_up, top_down)
    degs_allclean <- degs_allclean[!(degs_allclean$gene %in% selection_genes), ] %>%
      rbind(degs_allclean[degs_allclean$gene %in% selection_genes, ])
    col_custom <- ifelse(degs_allclean$gene %in% pathway_genes[[1]], cols[1],
                         ifelse(degs_allclean$gene %in% pathway_genes[[2]], cols[2],
                                ifelse(degs_allclean$gene %in% pathway_genes[[3]], cols[3],
                                       ifelse(degs_allclean$gene %in% pathway_genes[[4]],  cols[4],
                                              ifelse(degs_allclean$gene %in% pathway_genes[[5]], cols[5],
                                                           ifelse(degs_allclean$gene %in% c(top_up, top_down), 'grey1',
                                                              'grey'))))))
    
    # Assign category names
    names(col_custom)[col_custom == cols[1]] <- names(gene_lists[1])
    names(col_custom)[col_custom ==cols[2]] <- names(gene_lists[2])
    names(col_custom)[col_custom ==cols[3]] <- names(gene_lists[3])
    names(col_custom)[col_custom == cols[4]] <- names(gene_lists[4])
    names(col_custom)[col_custom == cols[4]] <- names(gene_lists[5])
    names(col_custom)[col_custom == 'grey1'] <- 'Top up or down' 
    }

# Filter colors for selected genes
col_custom_sub <- col_custom[degs_allclean$gene %in% unique(selection_genes)]

# Generate Enhanced Volcano Plot
volcano_plot <- EnhancedVolcano(degs_allclean, lab = degs_allclean$gene, 
                                x = 'avg_log2FC', y = 'p_val_adj',
                                selectLab = unique(selection_genes), 
                                labSize = 4, labCol = col_custom_sub,
                                title = title_plot, colAlpha = transparency,
                                subtitle = paste0('DEGs with p-val < 0.05 total genes:', length(degs_p$gene), '   (Min % applied: ',pct_min*100,'%)' ),
                                legendPosition = 'top',boxedLabels = boxed_tables,
                                pCutoff = pval_cutoff, FCcutoff = logfc_cutoff_line,
                                legendLabSize = 10, colCustom = col_custom,
                                legendIconSize = 5, drawConnectors = TRUE, arrowheads = T,typeConnectors = 'closed',
                                widthConnectors = 0.5, colConnectors = 'black') +
  scale_x_continuous(limits = c(-lim, lim)) + 
  scale_y_continuous(trans='pseudo_log')

# Save plot
cairo_pdf(filename = output_file, width = 13, height = 10)
print(volcano_plot)
dev.off()
return(col_custom)

}

# Example Usage:
# Define gene lists
gene_lists <- list(
  VEGF = c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1","Flt4", "Nrp1", "Nrp2", 'Kdr'),
  Apoptosis = c('Birc5','Brca1','Cdc25b', 'Casp9', 'Bik','Atf3', 'Txnip', 'Tspo', 'Gsr', 
                'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax', 'Gadd45a'),
  TipCell = c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", 
              "Aqp1", "Apln", "Dll4", "Spry4"),
  Vein = c('Nr2f2', 'Fbln2', 'Vwf', 'Vegfc', 'Car8', 'Cpe', 'Col14a1', 'Pgm5',
           'Prss23', 'Cd81', 'Lyve1', 'Csrp2', 'Slca6a2', 'Cd200', 'Vcam1', 'Bst1')
)

