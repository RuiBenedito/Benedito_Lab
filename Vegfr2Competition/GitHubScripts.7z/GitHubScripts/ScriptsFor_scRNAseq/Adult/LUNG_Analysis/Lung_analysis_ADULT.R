library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(SCpubr)
library(ggVennDiagram)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/2_VEQxAJDxKDR_ADULT_KDRMut260924_Ctrl191224/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/2_VEQxAJDxKDR_ADULT_KDRMut260924_Ctrl191224/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/2_VEQxAJDxKDR_ADULT_KDRMut260924_Ctrl191224/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/2_VEQxAJDxKDR_ADULT_KDRMut260924_Ctrl191224/3_Functions/FUNCTION_VolcanoPlot.R')

# Colors for the plots ################################
Colors_1to20 <- c(
  '0' = '#adfa36',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#66D9D9", # Light Cyan
  '13' = "#F2A766", # Light Copper
  '14'= "#F2A766", # Light Brown
  '15' = "#C266FF", # Bright Purple
  '16' = "#FFA07A", # Light Salmon
  '17' = "#7FFFD4", # Aquamarine
  '18' = "#FFD700", # Gold
  '19' = "#DC143C", # Crimson Red
  '20' = "#00CED1"  # Dark Turquoise
)


adult_lung_cols2nd <- c( 'Arteries'= "#FF6666",'Veins' = "#2a53c9", 'Cap'= "#F2A766", 
                      'VeinCap'= "#66B3FF",'Proliferative' = "#C266FF", 'Car4+Cap'= "#66E0A5" )

rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")

#Combined markers for the dotplot (this dot plot is shared among short term and long term samples and will be shown once to identify the cell type markers)
Idents(adult_lung) <-'celltypes2nd'
lung_degs <- FindAllMarkers(adult_lung, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
lung_degs_car4neg <- FindAllMarkers(subset(adult_lung, idents='Car4+Cap', invert=T),logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
mixed_degs <- rbind(lung_degs, lung_degs_car4neg)
mixed_degs <- mixed_degs[unique(mixed_degs$gene),]
lung_top10_mixed <- mixed_degs[unique(mixed_degs$gene),] %>% group_by(cluster) %>% top_n(10, avg_log2FC)
cluster_separations <- c(5.5,8.5,16.5,26.5,36.5,46.5)
cluster_boxes <- data.frame(
  xmin =  c(0.5, cluster_separations[-length(cluster_separations)]),  # Start of each cluster
  xmax = cluster_separations,  # End of each cluster
  ymin = Inf,   # Extends full y-axis
  ymax = 6.3,    
  fill = adult_lung_cols2nd # Custom colors per cluster
)
a<-DotPlot(adult_lung, features = lung_top10_mixed$gene[1:46], group.by = 'celltypes2nd', col.min = 0)&
  scale_colour_gradientn(colours = rz_palette)&ggtitle('Top gene markers per cluster')&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'), axis.title = element_blank())&
  geom_rect(data = cluster_boxes, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill), 
            alpha =1, inherit.aes = FALSE) &
  geom_vline(xintercept = cluster_separations, linetype = "dashed", color = "black", size = 0.8)&
  scale_fill_identity()
cairo_pdf(filename = 'Dotplot_CelltypeMarkers.pdf', width = 19, height = 5)
a
dev.off()

#Plot Kdr levels depending on the cell type 
Idents(adult_lung) <- 'genotype'
adult_lung_ctrl <- subset(adult_lung, idents='Ctrl')
Idents(adult_lung_ctrl)<-'celltypes2nd'
a<-VlnPlot(subset(adult_lung_ctrl, downsample= 86), group.by = 'celltypes2nd',ncol = 1, features = c('Kdr'), cols = adult_lung_cols2nd)&
  ggtitle('Kdr expression Lung (Adult)')&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=6), axis.title = element_blank(),
        legend.position = 'none', title = element_text(size=10))
b<-DotPlot(adult_lung_ctrl, features = 'Kdr', group.by = 'celltypes2nd', col.min = 0)& coord_flip()&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic', size = 8),title = element_blank(),
        axis.title = element_blank(), legend.key.size = unit(0.4, "cm"))

cairo_pdf(filename = 'VlnplotKdr_PerCellType_Ctrl.pdf', width = 10, height = 5)
grid.arrange(a, b, layout_matrix=rbind(c(1,1,1,1,1,1,1,NA), c(1,1,1,1,1,1,1,NA), c(2,2,2,2,2,2,2,2),c(2,2,2,2,2,2,2,2)))
dev.off()

#Start summary with only mutant animal sample
Idents(adult_lung) <- 'genotype'
adult_lung_kdr <- subset(adult_lung, idents='Ctrl', invert=T)

#Plot violin of deletion and dotplot
a<-VlnPlot(subset(adult_lung_kdr, downsample= 988), group.by = 'genotype',ncol = 1, features = c('kdr_exon30Norm'), cols = c('Kdr_TomNeg'='#0fc082', 'Kdr_TomPos'='#FF6666'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=6), axis.title = element_blank(), legend.position = 'none', title = element_text(size=10))
b<-VlnPlot(subset(adult_lung_kdr, downsample= 988), group.by = 'genotype',ncol = 1, features = c('kdr_exon3Norm'), cols = c('Kdr_TomNeg'='#0fc082', 'Kdr_TomPos'='#FF6666'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=6), axis.title = element_blank(), legend.position = 'none',  title = element_text(size=10))
c<-DotPlot(adult_lung_kdr, features = c('kdr_exon3Norm', 'kdr_exon30Norm'), group.by = 'genotype', scale = F, col.min = 0, scale.max = 100, dot.scale = 10)&
  scale_color_gradientn(colors = rz_palette)&coord_flip()&
  theme(legend.position = 'right', axis.title = element_blank(),axis.text.y = element_text(angle=90, hjust = 0.5),
        legend.key.size = unit(0.3, 'cm'), axis.text.x = element_text(size=7),
        legend.text = element_text(size = 5), 
        legend.spacing.x = unit(0.3, 'cm'), legend.title = element_text(size=5))

mt <- rbind(c(1,3,NA,NA), c(2,3,NA,NA))
cairo_pdf(filename = 'Vlnplot_DeletionKdr_DotplotCombined.pdf', width = 4, height = 5)
grid.arrange(a,b,c, layout_matrix=mt)
dev.off()

#Plot violin of deletion and dotplot
a<-VlnPlot(subset(adult_lung_kdr, downsample= 988), group.by = 'genotype',ncol = 1, features = c('Kdr'), cols = c('Kdr_TomNeg'='#0fc082', 'Kdr_TomPos'='#FF6666'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=6), axis.title = element_blank(), legend.position = 'none', title = element_text(size=10))
b<-DotPlot(adult_lung_kdr, features = c('Kdr'), group.by = 'genotype', scale = F, col.min = 0, scale.max = 100, scale.min = 0, dot.scale = 10)&
  scale_color_gradientn(colors = rz_palette)&coord_flip()&
  theme(legend.position = 'right', axis.title = element_blank(),axis.text.y = element_text(angle=90, hjust = 0.5),
        legend.key.size = unit(0.3, 'cm'), axis.text.x = element_text(size=7),
        legend.text = element_text(size = 5), 
        legend.spacing.x = unit(0.3, 'cm'), legend.title = element_text(size=5))
cairo_pdf(filename = 'Vlnplot_DeletionKdrFull_DotplotCombined.pdf', width = 5, height = 3)
grid.arrange(a,b, ncol=2)
dev.off()

t<-b$data
t$total <- t$avg.exp*t$pct.exp
write.csv(t, file='KdrDeletionPercentages.csv')
#Do summary with umap and barplots 
Idents(adult_lung_kdr) <- 'genotype'
a<-DimPlot(subset(adult_lung_kdr, downsample= 988), reduction = 'dim28lung', group.by = 'celltypes2nd', pt.size = 0.5,
           cols = adult_lung_cols2nd, split.by = 'genotype')+theme(legend.position = 'none',  plot.title = element_blank())
Idents(adult_lung_kdr) <- 'celltypes2nd'
alf<-sort(levels(adult_lung_kdr))
real <-levels(adult_lung_kdr)
reorder<-as.numeric(factor(real, levels = alf))
Idents(adult_lung_kdr) <- 'genotype'
b<-dittoBarPlot(adult_lung_kdr, var = 'celltypes2nd', group.by = 'genotype', color.panel = adult_lung_cols2nd, var.labels.reorder = reorder)+
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5), axis.title.x = element_blank())+ggtitle('ECs subtypes Lung')
c<-DimPlot(subset(adult_lung_kdr, downsample= 988), reduction = 'dim28lung', group.by = 'genotype',shuffle = T,pt.size = 0.5,
           cols = c('Kdr_TomNeg'='#0fc082', 'Kdr_TomPos'='#FF6666'))+
  theme(legend.position = 'bottom', axis.title = element_blank())+ggtitle('UMAP KdrKO vs Ctrl distribution') 
s<-b$data #To add log2FC graph
celltype_names <-unique(s$label)
results_table <- data.frame()
for (cell in celltype_names){
  mut <- s[s$label==cell & s$grouping=='Kdr_TomNeg',]
  ctrl<-s[s$label==cell & s$grouping=='Kdr_TomPos',]
  ratio <- mut$percent/ctrl$percent
  log2fc <- log2(ratio)
  results_table <- rbind(results_table, data.frame(CellType = cell, Ratio = ratio, Log2Ratio=-log2fc))
}
results_table <- results_table[reorder,]
results_table$CellType <- factor(results_table$CellType, levels = results_table$CellType)
d<- ggplot(data = results_table, aes(y = Log2Ratio, x = CellType, fill = Log2Ratio > 0)) +  
  geom_col() +  
  scale_fill_manual(values = c("FALSE" = '#0fc082', "TRUE" = 'tomato')) +  # Assign colors
  theme_minimal() + scale_y_continuous(limits = c(-3,3)) +
  labs(title = "Log2 Ratio by Cell Type", y = "Log2 Ratio", x = "Cell Type") +
  theme(axis.text.y = element_text(face = "italic"),
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title.x = element_blank()) +
  guides(fill = "none")  # Removes legend if not needed
mt <- rbind(c(1,1,1,1,1,2,2,2,3,3,3,4,4,NA,NA))
cairo_pdf(filename = 'Summary_UMAP_Barplot_SecondOption.pdf', width = 15, height =4)
print(grid.arrange(a,b,c,d, layout_matrix=mt))
dev.off()

#Filter possible contaminant genes
filter_results_lung <- FilterLowExpressionGenes_onlytable(adult_lung_kdr, filt_th = 1.7, min_cells = 10)
genes_selected <- filter_results_lung$genes_filtered
tablesum <- filter_results_lung$gene_per
write.csv(tablesum, file='FilterGenes_LungSkewness.csv')

Idents(adult_lung_kdr) <- 'genotype'
degs_lung <- FindMarkers(adult_lung_kdr, ident.1 = "Kdr_TomPos" , ident.2 ="Kdr_TomNeg",min.pct = 0.05, features = genes_selected, densify = T)
degs_lung$gene <- rownames(degs_lung)
write.csv(degs_lung, file='DEGs_PerGenotype_FilteredSkewness.csv')

#Filter genes that are not significant or not expressed at all in the control.
#clean gene set no significance or fold change selection
degs_lung_cl <-degs_lung[degs_lung$pct.2>=0.050 & degs_lung$pct.1>=0.050,] 
degs_lung_cl_new <-degs_lung[degs_lung$pct.2>=0.02 & degs_lung$pct.1>=0.02,] 
#Significance selection
degs_lung_p <- degs_lung_cl[degs_lung_cl$p_val_adj<0.05,]
degs_lung_p_new <- degs_lung_cl_new[degs_lung_cl_new$p_val_adj<0.05,]
#Fold change selection and significance
degs_lung_fc <- degs_lung_p[abs(degs_lung_p$avg_log2FC)>1,] 
degs_lung_fc2 <- degs_lung_p[abs(degs_lung_p$avg_log2FC)>0.5,] 
degs_lung_fc2_new <- degs_lung_p_new[abs(degs_lung_p_new$avg_log2FC)>0.5,] 
#Only fold change
degs_lung_fc_all <-degs_lung_cl[abs(degs_lung_cl$avg_log2FC)>0.5,]
degs_lung_fc_all_new <-degs_lung_cl_new[abs(degs_lung_cl_new$avg_log2FC)>0.5,]


# Generate fgsea plot using the function and a clean set of DEGs with p_val and percentage filter
FGSEA_Table_Plot(degs_lung_cl, extra_name = 'Lung_DEGs_MutvsTomNeg', min_size = 10, filter_pval = T)


# ////////////////////////Generate VOLCANO /////////////////////////////////////////////----

#Selected gendegs_lung_fc05_old#Selected genes (Only filter for logfc)
selected_genes <- list(
  VEGF_pathway = c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1","Flt4", "Nrp1", "Nrp2", 'Kdr'),
  Apoptosis_genes = c('Birc5','Brca1','Cdc25b', 'Casp9', 'Bik','Atf3', 'Txnip', 'Tspo', 'Gsr', 
                      'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax', 'Gadd45a'),
  TipCell_genes = c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", 
                    "Aqp1", "Apln", "Dll4", "Spry4"),
  Vein_genes = c('Nr2f2', 'Fbln2', 'Vwf', 'Vegfc', 'Car8', 'Cpe', 'Col14a1', 'Pgm5',
                 'Prss23', 'Cd81', 'Lyve1', 'Csrp2', 'Slca6a2', 'Cd200', 'Vcam1', 'Bst1'), 
  Proliferation =c('Prc1', 'Mki67', 'Top2a', 'Birc5', 'Lockd', 'Cdca8', 'Cks1b', 'Cks2', 'Lmnb1', 'Hmgb2')
)

#Select genes from hallmarks (Filter for significance)
fgsea_table_ord <- fgsea_table[fgsea_table$padj<0.05,] %>% arrange(desc(NES))

#Standard volcano with the DEGS only genes
generate_volcano_plot(degs_table = degs_lung, fgsea_table = fgsea_table_ord, gene_list_max5 = selected_genes, title_plot = 'Volcano Lung (Tom+ vs Tom-)')

#Add proliferation and other genes 
degs_proliferation <- FindMarkers(adult_lung_kdr, ident.1 = "Kdr_TomPos" , ident.2 ="Kdr_TomNeg",min.pct = 0, features = c('Prc1', 'Mki67', 'Top2a', 'Birc5', 'Lockd', 'Cdca8', 'Cks1b', 'Cks2', 'Lmnb1', 'Hmgb2', 'Esm1', 'Kcne3'), densify = T)
degs_proliferation$gene <- rownames(degs_proliferation)
degs_total <- rbind(degs_lung, degs_proliferation)
degs_total <- degs_total[unique(degs_total$gene),]

generate_volcano_plot(degs_table = degs_total, fgsea_table = fgsea_table_ord, gene_list_max5 = selected_genes,output_file = 'VolcanoPlot_Extragenes.pdf',
                      title_plot = 'Volcano Lung (Tom+ vs Tom-)')

#//////////////Heatmap for selected genes ////////////////------
vegf_genes <- c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1","Flt4", "Nrp1", "Nrp2")
#One column
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, rds_object = adult_lung_kdr,
                                           first_var = 'genotype', ident_1 ="Kdr_TomPos" ,lim_minus = -2, lim_max = 2,
                                           title = 'VEGF pathway genes (Adult lung)',order_genes_name = T,
                                           ident_2 = "Kdr_TomNeg", name_pdf = 'VEGF_pathway_Heatmap', w=1)
#Per cell type
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, rds_object = adult_lung_kdr,second_var = 'celltypes2nd',
                                           first_var = 'genotype', ident_1 ="Kdr_TomPos" , lim_minus = -2, lim_max = 2,
                                           title = 'VEGF pathway genes (Adult lung)',order_genes_name = T,long_factor = 5,
                                           ident_2 = "Kdr_TomNeg", name_pdf = 'VEGF_pathway_Heatmap_PerCelltype', w=3)

#Tip cells heatmapts
tipcell_markers <- c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", "Aqp1", "Apln", "Dll4", "Spry4")
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = tipcell_markers, rds_object = adult_lung_kdr,
                                           first_var = 'genotype', ident_1 ="Kdr_TomPos" ,lim_minus = -2, lim_max = 2,
                                           title = 'Tip cell pathway genes (Adult Lung)',
                                           ident_2 = "Kdr_TomNeg", name_pdf = 'TipCell_pathway_Heatmap', w=1)
#Apoptosis cells heatmapts
apoptosis_genes <- c( 'Birc5','Brca1','Cdc25b', 'Casp9', 'Bik','Top2a','Atf3', 'Txnip', 'Tspo', 'Gsr', 'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax', 'Gadd45a')
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = apoptosis_genes, rds_object = adult_lung_kdr,
                                           first_var = 'genotype', ident_1 ="Kdr_TomPos" ,lim_minus = -2, lim_max = 2,
                                           title = 'Apoptosis pathway genes(Adult lung)',
                                           ident_2 = "Kdr_TomNeg", name_pdf = 'Apoptosis_pathway_Heatmap', w=1)
#Per cell type vein markers
veins_genes <- c('Nr2f2', 'Fbln2', 'Vwf', 'Vegfc', 'Car8', 'Cpe', 'Col14a1', 'Pgm5',
                 'Prss23', 'Cd81', 'Lyve1', 'Csrp2',
                 'Slca6a2', 'Cd200', 'Vcam1', 'Bst1')
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = veins_genes, rds_object = adult_lung_kdr,
                                           first_var = 'genotype', ident_1 ="Kdr_TomPos" ,lim_minus = -2, lim_max = 2,
                                           title = 'Vein genes (Adult lung)',
                                           ident_2 = "Kdr_TomNeg", name_pdf = 'Vein_genes_Heatmap', w=1)
#Per cell type
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = veins_genes, rds_object = adult_lung_kdr,second_var = 'celltypes2nd',
                                           first_var = 'genotype', ident_1 ="Kdr_TomPos" , lim_minus = -2, lim_max = 2,
                                           title = 'Vein genes (Adult lung)',order_genes_name = T,long_factor = 5,
                                           ident_2 = "Kdr_TomNeg", name_pdf = 'VeinGenes_Heatmap_PerCelltype', w=3)

