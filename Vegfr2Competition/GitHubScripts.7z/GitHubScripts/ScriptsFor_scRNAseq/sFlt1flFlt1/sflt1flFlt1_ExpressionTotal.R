library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(SCpubr)
library(ggVennDiagram)

Colors_1to20 <- c(
  '0' = '#adfa36',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#66D9D9", # Light Cyan
  '13' = "#F2A766", # Light Copper
  '14' = "#D88A6D", # Light Brown
  '15' = "#C266FF", # Bright Purple
  '16' = "#FFA07A", # Light Salmon
  '17' = "#7FFFD4", # Aquamarine
  '18' = "#FFD700", # Gold
  '19' = "#DC143C", # Crimson Red
  '20' = "#00CED1"  # Dark Turquoise
)

Colors_1to10 <- c(
  '0' = '#adfa36',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF") 

Bestholtz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")



st_all$Flt1_E13b_norm <- log((st_all$Flt1_E13b*10^4/st_all$nCount_RNA)+1)
st_all$Flt1_E13b_norm[is.na(st_all$Flt1_E13b_norm)] <-0
st_all$Flt1_E14_norm <- log((st_all$Flt1_E14*10^4/st_all$nCount_RNA)+1)
st_all$Flt1_E14_norm[is.na(st_all$Flt1_E14_norm)] <-0

st_all$Flt1_E30_norm <- log((st_all$Flt1_E30*10^4/st_all$nCount_RNA)+1)
st_all$Flt1_E30_norm[is.na(st_all$Flt1_E30_norm)] <-0

st_all$Flt1_E13b_minusE14 <- log(((st_all$Flt1_E13b-st_all$Flt1_E14)*10^4/st_all$nCount_RNA)+1)
st_all$Flt1_E13b_minusE14[is.na(st_all$Flt1_E13b_minusE14)] <-0
st_all <- JoinLayers(st_all)

#Divide by organs
Idents(st_all) <- 'tissue.y'
st_brain_sub <- subset(st_all, idents='Brain')
st_heart_sub <- subset(st_all, idents='Heart')
st_lung_sub <- subset(st_all, idents='Lung')
st_kidney_sub <- subset(st_all, idents='Kidney')


#Brain
#to plot dotplots with % numbers
Idents(st_brain_sub) <- 'Sample'
levels(st_brain_sub)
levels(Idents(st_brain_sub)) <- c('KdrMut', 'KdrMut', 'Ctrl', 'Ctrl')
st_brain_sub$simple_genotype <- Idents(st_brain_sub)

p<-dotplot_percentage(st_brain_sub, features =c('Flt1_E13b_norm', 'Flt1_E14_norm', 'Flt1_E30_norm'),
                      group.by ='simple_genotype',title='Short term Brain exons expression'  )
a <- p$plot
dot_data <- p$data
genotype_groups <-unique(dot_data$id)
results_table <- data.frame()
for (gp in genotype_groups){
  e13 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E13b_norm',]
  e30 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E30_norm',]
  e14 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E14_norm',]
  ratio <- e13$exp/e30$exp
  ratio_inv <- if (ratio < 1) { -1 / ratio } else { ratio }
  log2fc <- log2(ratio)
  ratio_norm <- (e13$exp - e14$exp)/e30$exp
  ratio_inv_norm <- if (ratio_norm < 1) { -1 / ratio_norm } else { ratio_norm }
  results_table <- rbind(results_table, data.frame(genotype_groups = gp, Ratio = ratio,Foldchange=ratio_inv,
                                                   Log2Ratio=-log2fc, Ratio_norm=ratio_norm, Foldchange_norm=ratio_inv_norm))
}
write.csv(results_table, file='ResultsTable_ShortTerm_AbsExpression_Ratios_Brain.csv')

#lung
#to plot dotplots with % numbers
Idents(st_lung_sub) <- 'Sample'
levels(st_lung_sub)
levels(Idents(st_lung_sub)) <- c('KdrMut', 'KdrMut', 'Ctrl', 'Ctrl')
st_lung_sub$simple_genotype <- Idents(st_lung_sub)

p<-dotplot_percentage(st_lung_sub, features =c('Flt1_E13b_norm', 'Flt1_E14_norm', 'Flt1_E30_norm'),
                      group.by ='simple_genotype',title='Short term Lung exons expression'  )
a <- p$plot
dot_data <- p$data

genotype_groups <-unique(dot_data$id)
results_table <- data.frame()
for (gp in genotype_groups){
  e13 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E13b_norm',]
  e30 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E30_norm',]
  e14 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E14_norm',]
  ratio <- e13$exp/e30$exp
  ratio_inv <- if (ratio < 1) { -1 / ratio } else { ratio }
  log2fc <- log2(ratio)
  ratio_norm <- (e13$exp - e14$exp)/e30$exp
  ratio_inv_norm <- if (ratio_norm < 1) { -1 / ratio_norm } else { ratio_norm }
  results_table <- rbind(results_table, data.frame(genotype_groups = gp, Ratio = ratio,Foldchange=ratio_inv,
                                                   Log2Ratio=-log2fc, Ratio_norm=ratio_norm, Foldchange_norm=ratio_inv_norm))
}
write.csv(results_table, file='ResultsTable_ShortTerm_AbsExpression_Ratios_Lung.csv')

#Kidney
#to plot dotplots with % numbers
Idents(st_Kidney_sub) <- 'Sample'
levels(st_Kidney_sub)
levels(Idents(st_Kidney_sub)) <- c('KdrMut', 'KdrMut', 'Ctrl')
st_Kidney_sub$simple_genotype <- Idents(st_Kidney_sub)

p<-dotplot_percentage(st_Kidney_sub, features =c('Flt1_E13b_norm', 'Flt1_E14_norm', 'Flt1_E30_norm'),
                      group.by ='simple_genotype',title='Short term Kidney exons expression'  )
a <- p$plot
dot_data <- p$data

genotype_groups <-unique(dot_data$id)
results_table <- data.frame()
for (gp in genotype_groups){
  e13 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E13b_norm',]
  e30 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E30_norm',]
  e14 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E14_norm',]
  ratio <- e13$exp/e30$exp
  ratio_inv <- if (ratio < 1) { -1 / ratio } else { ratio }
  log2fc <- log2(ratio)
  ratio_norm <- (e13$exp - e14$exp)/e30$exp
  ratio_inv_norm <- if (ratio_norm < 1) { -1 / ratio_norm } else { ratio_norm }
  results_table <- rbind(results_table, data.frame(genotype_groups = gp, Ratio = ratio,Foldchange=ratio_inv,
                                                   Log2Ratio=-log2fc, Ratio_norm=ratio_norm, Foldchange_norm=ratio_inv_norm))
}
write.csv(results_table, file='ResultsTable_ShortTerm_AbsExpression_Ratios_Kidney.csv')

#heart
#to plot dotplots with % numbers
Idents(st_heart_sub) <- 'Sample'
levels(st_heart_sub)
levels(Idents(st_heart_sub)) <- c('KdrMut', 'KdrMut', 'Ctrl', 'Ctrl')
st_heart_sub$simple_genotype <- Idents(st_heart_sub)
p<-dotplot_percentage(st_heart_sub, features =c('Flt1_E13b_norm', 'Flt1_E14_norm', 'Flt1_E30_norm'),
                      group.by ='simple_genotype',title='Short term Heart exons expression'  )
a <- p$plot
dot_data <- p$data
genotype_groups <-unique(dot_data$id)
results_table <- data.frame()
for (gp in genotype_groups){
  e13 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E13b_norm',]
  e30 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E30_norm',]
  e14 <- dot_data[dot_data$id==gp & dot_data$features.plot=='Flt1_E14_norm',]
  ratio <- e13$exp/e30$exp
  ratio_inv <- if (ratio < 1) { -1 / ratio } else { ratio }
  log2fc <- log2(ratio)
  ratio_norm <- (e13$exp - e14$exp)/e30$exp
  ratio_inv_norm <- if (ratio_norm < 1) { -1 / ratio_norm } else { ratio_norm }
  results_table <- rbind(results_table, data.frame(genotype_groups = gp, Ratio = ratio,Foldchange=ratio_inv,
                                                   Log2Ratio=-log2fc, Ratio_norm=ratio_norm, Foldchange_norm=ratio_inv_norm))
}
write.csv(results_table, file='ResultsTable_ShortTerm_AbsExpression_Ratios_Heart.csv')


#Plot all the graphs together short term

st_brain <-  read_csv("...ResultsTable_ShortTerm_AbsExpression_Ratios_Brain.csv")
st_heart <- read_csv("...ResultsTable_ShortTerm_AbsExpression_Ratios_Heart.csv")
st_kidney <- read_csv("...ResultsTable_ShortTerm_AbsExpression_Ratios_Kidney.csv")
st_lung <- read_csv("...ResultsTable_ShortTerm_AbsExpression_Ratios_Lung.csv")

st_brain$organ <-'brain'
st_heart$organ <- 'heart'
st_lung$organ <- 'lung'
st_kidney$organ <- 'kidney'
st_all_ratios <- rbind(st_brain, st_heart, st_lung, st_kidney)
st_all_ratios <- st_all_ratios[-1]

a<-ggplot(st_all_ratios, aes(x = organ, y = Ratio, fill = genotype_groups)) +
  geom_col(position = position_dodge(width = 0.9)) +
  geom_text(aes(label =  paste0("FC: ", round(Foldchange, 2)) ), 
            position = position_dodge(width = 0.8), 
            vjust = -0.5, size = 2) +
  scale_fill_manual(values = c("Ctrl" = "grey", "KdrMut" = "tomato")) +
  labs(title = "Ratio E13b/E30 by Organ and Genotype",
       y = "Ratio (soluble/membrane)") +
  theme_minimal() + 
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5), axis.title.x = element_blank())
cairo_pdf('Sumary_AbsExpression_AllOrgans_flt1Expression_ShortTerm.pdf', width = 15, height = 5)
a
dev.off()


