library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(Heatmap)
library(SCpubr)
library(ggVennDiagram)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')

Colors_1to20 <- c(
  '0' = '#adfa36',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#66D9D9", # Light Cyan
  '13' = "#F2A766", # Light Copper
  '14' = "#D88A6D", # Light Brown
  '15' = "#C266FF", # Bright Purple
  '16' = "#FFA07A", # Light Salmon
  '17' = "#7FFFD4", # Aquamarine
  '18' = "#FFD700", # Gold
  '19' = "#DC143C", # Crimson Red
  '20' = "#00CED1"  # Dark Turquoise
)
kidney_cols <-c('Cap1'="#FFCC66", 'Cap2'="#D88A6D",'Cap3'="#FFFF66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
                'Arteries'="#ec245b","PreProlif"="#B366FF",  "Prol-G2Mphase"='#0fc082',
                "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue', 'Angio'= '#adfa36')


rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")


comb.kidney <- JoinLayers(comb.kidney)

comb.kidney <- NormalizeData(comb.kidney, normalization.method = "LogNormalize", scale.factor = 10000)
comb.kidney <- subset(comb.kidney, subset = nFeature_RNA > 500 & nFeature_RNA < 6000 &  nCount_RNA > 2000 & nCount_RNA < 30000)
comb.kidney <- subset(comb.kidney, subset= Cdh5>0.1 & Ptprc<0.1)
comb.kidney <- NormalizeData(comb.kidney, normalization.method = "LogNormalize", scale.factor = 10000)
comb.kidney <- FindVariableFeatures(comb.kidney, selection.method = "vst")
comb.kidney <- ScaleData(comb.kidney) 
comb.kidney <- RunPCA(comb.kidney ) # use this genes to reduce tech variability among ports of my samples
ElbowPlot(comb.kidney, ndims = 50, reduction = 'pca')
Idents(comb.kidney) <- 'experiment' #Variable that indicates the port of sequencing
comb.kidney <- RunHarmony(comb.kidney, "experiment", plot_convergence = TRUE)
a<-DimPlot(comb.kidney, reduction = "pca", pt.size = 0.5, group.by = "experiment", shuffle = T )+
  ggtitle('No HARMONY')+theme(legend.position = 'bottom')
b<-DimPlot(comb.kidney, reduction = "harmony", pt.size = 0.5, group.by = "experiment", shuffle = T)+
  ggtitle('HARMONY')+theme(legend.position = 'none')
cairo_pdf(filename = 'Harmony_kidney.pdf', width = 15, height = 5)
print(grid.arrange(a, b, ncol=2))
dev.off()


#1st First filter to see cell types
comb.kidney <- FindNeighbors(comb.kidney, dims = 1:35, reduction="harmony")
comb.kidney <- FindClusters(comb.kidney, resolution = 0.8, cluster.name = 'res0.8kidney')
comb.kidney<-RunUMAP(comb.kidney, dims = 1:35,  reduction.name = "dim35kidney",return.model = T, reduction = 'harmony')
#Identify markers to see contaminant clusters
kidney_degs <- FindAllMarkers(comb.kidney, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
kidney_top10 <- kidney_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.kidney, reduction = 'dim35kidney', group.by = 'res0.8kidney', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.kidney, var = 'res0.8kidney', group.by = 'genotype', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.kidney, features = unique(kidney_top10$gene), group.by = 'res0.8kidney')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(comb.kidney, features = 'Igfbp5', group.by = 'res0.8kidney', cols = Colors_1to20)+theme(legend.position = 'none')
d2<-VlnPlot(comb.kidney, features = 'nFeature_RNA', group.by = 'res0.8kidney', cols = Colors_1to20)+theme(legend.position = 'none')
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()


saveRDS(comb.kidney, file='Cobined_kidney_v1.rds')
#Remove cluster 11/12/13/14 because they are clearly contaminant or doublets and do not clusterise with the main group. 
comb.kidney2 <- subset(comb.kidney, idents=c(11,12,13,14), invert=T)

Idents(comb.kidney2)<-'genotype'
comb.kidney2 <- NormalizeData(comb.kidney2, normalization.method = "LogNormalize", scale.factor = 10000)
comb.kidney2 <- FindVariableFeatures(comb.kidney2, selection.method = "vst")
comb.kidney2 <- ScaleData(comb.kidney2) 
comb.kidney2 <- RunPCA(comb.kidney2 ) # use this genes to reduce tech variability among ports of my samples
ElbowPlot(comb.kidney2, ndims = 50, reduction = 'pca')
comb.kidney2 <- FindNeighbors(comb.kidney2, dims = 1:29, reduction="harmony")
comb.kidney2 <- FindClusters(comb.kidney2, resolution = 0.8, cluster.name = 'res0.8kidney2')
comb.kidney2<-RunUMAP(comb.kidney2, dims = 1:29,  reduction.name = "dim29kidney2",return.model = T, reduction = 'harmony')
#Identify markers to see contaminant clusters
kidney_degs <- FindAllMarkers(comb.kidney2, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
kidney_top10 <- kidney_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.kidney2, reduction = 'dim29kidney2', group.by = 'res0.8kidney2', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.kidney2, var = 'res0.8kidney2', group.by = 'genotype', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.kidney2, features = unique(kidney_top10$gene), group.by = 'res0.8kidney2')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(comb.kidney2, features = 'Igfbp5', group.by = 'res0.8kidney2', cols = Colors_1to20)+theme(legend.position = 'none')
d2<-VlnPlot(comb.kidney2, features = 'Lyve1', group.by = 'res0.8kidney2', cols = Colors_1to20)+theme(legend.position = 'none')
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined2.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()

#Remove these because they do not express Kidney markers (C8) or they belong to doublets from kidney cells
comb.kidney3 <- subset(comb.kidney2, idents=c(8,10,11,12), invert=T)
comb.kidney3 <- NormalizeData(comb.kidney3, normalization.method = "LogNormalize", scale.factor = 10000)
comb.kidney3 <- FindVariableFeatures(comb.kidney3, selection.method = "vst")
comb.kidney3 <- ScaleData(comb.kidney3) 
comb.kidney3 <- RunPCA(comb.kidney3 ) # use this genes to reduce tech variability among ports of my samples
ElbowPlot(comb.kidney3, ndims = 50, reduction = 'pca')
comb.kidney3 <- FindNeighbors(comb.kidney3, dims = 1:25, reduction="harmony")
comb.kidney3 <- FindClusters(comb.kidney3, resolution = 0.8, cluster.name = 'res0.8kidney2')
comb.kidney3<-RunUMAP(comb.kidney3, dims = 1:25,  reduction.name = "dim25kidney3",return.model = T, reduction = 'harmony')
#Identify markers to see contaminant clusters
kidney_degs <- FindAllMarkers(comb.kidney3, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
kidney_top10 <- kidney_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.kidney3, reduction = 'dim25kidney3', group.by = 'res0.8kidney2', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.kidney3, var = 'res0.8kidney2', group.by = 'genotype', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.kidney3, features = unique(kidney_top10$gene), group.by = 'res0.8kidney2')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(comb.kidney3, features = 'Gja4', group.by = 'res0.8kidney2', cols = Colors_1to20)+theme(legend.position = 'none')
d2<-VlnPlot(comb.kidney3, features = 'Igf1', group.by = 'res0.8kidney2', cols = Colors_1to20)+theme(legend.position = 'none')
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined3.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()


#Check best dimensional reduction
Idents(comb.kidney3) <- 'res0.8kidney2'
levels(Idents(comb.kidney3))
plots <- list()
dimensions_test <- c(20:30)
for (dim in dimensions_test){
  comb.kidney3 <- FindNeighbors(comb.kidney3, dims = 1:dim, reduction="harmony")
  name_red <- paste0('dim', dim, 'kidney')
  comb.kidney3<-RunUMAP(comb.kidney3, dims = 1:dim,  reduction.name = name_red,return.model = T, reduction = 'harmony')
  plots[[dim]] <-DimPlot(comb.kidney3, reduction = name_red, group.by = 'res0.8kidney2', 
                         cols = Colors_1to20, label = T, label.box = T)
}
cairo_pdf(filename = 'UMAP_DifferentDimensions_kidney.pdf', width = 20, height = 15)
plot_grid(plotlist= plots[20:30], ncol=4)
dev.off()

Idents(comb.kidney3) <- 'res0.8kidney2'
levels(Idents(comb.kidney3)) <- c('Cap1', 'Prol-Sphase', 'Veins', 'Cap2', 'Cap3','PreProlif', 'Prol-G2Mphase', 'Angio', 'Arteries')
comb.kidney3$celltype1 <- Idents(comb.kidney3)

#Normalized floxed exons reads
comb.kidney3$kdr_exon30Norm <- log((comb.kidney3$Kdr_exon30*10^4/comb.kidney3$nCount_RNA)+1)
comb.kidney3$kdr_exon3Norm <- log((comb.kidney3$Kdr_exon3*10^4/comb.kidney3$nCount_RNA)+1)
comb.kidney3$kdr_exon30Norm[is.na(comb.kidney3$kdr_exon30Norm)] <-0
comb.kidney3$kdr_exon30Norm[is.na(comb.kidney3$kdr_exon30Norm)] <-0


saveRDS(comb.kidney3, file='Cobined_kidney_v2.rds')
