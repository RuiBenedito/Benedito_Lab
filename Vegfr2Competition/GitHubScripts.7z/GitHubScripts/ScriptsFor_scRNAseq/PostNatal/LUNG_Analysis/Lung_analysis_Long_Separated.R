#Combine the two samples long and short term analysis oflung
library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(pheatmap)
library(SCpubr)
library(UpSetR)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_VolcanoPlot.R')

#Colors for graphs
Colors_1to15 <-  c(
  '0' = 'grey',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#FFCC66", # Coral
  '13' = "#66D9D9", # Light Cyan
  '14' = "#F2A766", # Light Copper
  '15' = "#D88A6D"  # Light Brown
)

lung_cols <-c('Cap'="#FFCC66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
              'Arteries'="#ec245b","Car4+High"="#B366FF", "Car4+Low" ="#e7d6f9" , "Prol-G2Mphase"='#0fc082',
              "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue')

rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")

#Start the analys from the comb.lung sample done in the: S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/2410_scRNA_AplnEMT_Kdr_P8_Postnatal/1_Scripts/Lung_analysis_short_longCombined.R
Idents(comb.lung) <- 'experiment_simple'
levels(comb.lung)
lung.long <- subset(comb.lung, ident='LongT')

# ////////////////////////////////////// Deletion plots and tables /////////////////----
#Do deletion plots and data
lung.long$kdr_exon30Norm[is.na(lung.long$kdr_exon30Norm)] <-0
lung.long$kdr_exon3Norm[is.na(lung.long$kdr_exon3Norm)] <- 0

#Older plot deletion
a<-DotPlot(lung.long, features = c('kdr_exon30Norm', 'kdr_exon3Norm', 'Kdr'), group.by = 'genotype', scale = F)
a <- a$data
a<- a%>% arrange(features.plot)
Idents(lung.long) <-'genotype'
a<-VlnPlot(subset(lung.long, downsample= 1125), group.by = 'genotype', features = c('Kdr',  'kdr_exon30Norm','kdr_exon3Norm'), cols = c('LongTerm_Ctrl'='#0fc082', 'LongTerm_Kdr'='#FF6666'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic'), axis.title = element_blank())
cairo_pdf(filename = 'Vlnplot_DeletionKdr_Longterm.pdf', width = 10, height = 3)
a
dev.off()
#////////////////////////////////// Summaries with UMAP and Barplots ///////////////////////----
#Do summary with umap and barplots
Idents(lung.long) <-'genotype'
sublung <- subset(lung.long, downsample=1125)
a<-DimPlot(sublung, reduction = 'dim29lung2', group.by = 'celltypesc', pt.size = 0.5,
           cols =lung_cols, split.by = 'genotype')+theme(legend.position = 'none',  plot.title = element_blank())
Idents(lung.long) <- 'celltypesc'
alf<-sort(levels(lung.long))
real <-levels(lung.long)
reorder<-as.numeric(factor(real, levels = alf))
Idents(lung.long) <- 'genotype'
b<-dittoBarPlot(lung.long, var = 'celltypesc', group.by = 'genotype', color.panel =lung_cols, var.labels.reorder = reorder)+
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5), axis.title.x = element_blank())+ggtitle('ECs subtypeslung')
c<-DimPlot(sublung, reduction = 'dim29lung2', group.by = 'genotype',shuffle = T,pt.size = 0.5,
           cols = c('LongTerm_Ctrl'='#0fc082', 'LongTerm_Kdr'='#FF6666'))+
  theme(legend.position = 'bottom', axis.title = element_blank())+ggtitle('UMAP KdrKO vs Ctrl distribution')
s<-b$data
celltype_names <-unique(s$label)
results_table <- data.frame()
for (cell in celltype_names){
  mut <- s[s$label==cell & s$grouping=='LongTerm_Ctrl',]
  ctrl<-s[s$label==cell & s$grouping=='LongTerm_Kdr',]
  ratio <- mut$percent/ctrl$percent
  log2fc <- log2(ratio)
  results_table <- rbind(results_table, data.frame(CellType = cell, Ratio = ratio, Log2Ratio=-log2fc))
}
results_table <- results_table[reorder,]
results_table$CellType <- factor(results_table$CellType, levels = results_table$CellType)
d<- ggplot(data = results_table, aes(y = Log2Ratio, x = CellType, fill = Log2Ratio > 0)) +  
  geom_col() +  
  scale_fill_manual(values = c("FALSE" = '#0fc082', "TRUE" = 'tomato')) +  # Assign colors
  theme_minimal() + scale_y_continuous(limits = c(-2,2)) +
  labs(title = "Log2 Ratio by Cell Type", y = "Log2 Ratio", x = "Cell Type") +
  theme(axis.text.y = element_text(face = "italic"),
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title.x = element_blank()) +
  guides(fill = "none")  # Removes legend if not needed
mt <- rbind(c(1,1,1,1,1,2,2,2,3,3,3,4,4,NA,NA))
cairo_pdf(filename = 'Summary_UMAP_Barplot_SecondOption.pdf', width = 15, height =4)
print(grid.arrange(a,b,c,d, layout_matrix=mt))
dev.off()



#///////////////// Extraction of DEGs and filtering ///////////////////////////////////////////////////////----
#Filter possible contaminant genes
filter_results_lung <- FilterLowExpressionGenes_onlytable(lung.long, filt_th = 1.7, min_cells = 10)
genes_selected <- filter_results_lung$genes_filtered
tablesum <- filter_results_lung$gene_per
write.csv(tablesum, file='FilterGenes_LungSkewness.csv')


DefaultAssay(lung.long) <- "RNA"
Idents(lung.long) <- 'genotype'
degs_lung <- FindMarkers(lung.long, ident.1 = "LongTerm_Kdr" , ident.2 ="LongTerm_Ctrl", min.pct = 0.05, features = genes_selected, densify = T)
degs_lung$gene <- rownames(degs_lung)
degs_lung <- rbind(degs_lung, Kdr_values)
write.csv(degs_lung, file='DEGs_PerGenotype_FilteredSkewness.csv')

#clean gene set no significance or fold change selection
degs_lung_cl <-degs_lung[degs_lung$pct.2>=0.050 & degs_lung$pct.1>=0.050,] 
degs_lung_cl_new <-degs_lung[degs_lung$pct.2>=0.02 & degs_lung$pct.1>=0.02,] 
#Significance selection
degs_lung_p <- degs_lung_cl[degs_lung_cl$p_val_adj<0.05,]
degs_lung_p_new <- degs_lung_cl_new[degs_lung_cl_new$p_val_adj<0.05,]
#Fold change selection and significance
degs_lung_fc <- degs_lung_p[abs(degs_lung_p$avg_log2FC)>1,] 
degs_lung_fc2 <- degs_lung_p[abs(degs_lung_p$avg_log2FC)>0.5,] 
degs_lung_fc2_new <- degs_lung_p_new[abs(degs_lung_p_new$avg_log2FC)>0.5,] 
#Only fold change
degs_lung_fc_all <-degs_lung_cl[abs(degs_lung_cl$avg_log2FC)>0.5,]
degs_lung_fc_all_new <-degs_lung_cl_new[abs(degs_lung_cl_new$avg_log2FC)>0.5,]

# ///////////////////////// HEATMAP and fGSEA for all DEGs ///////////////////////////////////----
#Plot heatmaps of DEGs among cell types with more than 1 of FC
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = degs_lung_fc$gene, rds_object =lung.long, first_var = 'genotype',
                                           second_var = 'celltypesc', ident_1 ="LongTerm_Kdr",title = 'DEGs with >1 abs(logFC)',
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'TopDEGs_1FC', w=7)


# Generate fgsea plot using the function and a clean set of DEGs with p_val and percentage filter

FGSEA_Table_Plot(degs_lung_cl, extra_name = 'Lung_DEGs_longermMutvsCtrl_Min5Percent', min_size = 15,  filter_pval = T)

# ////////////////////////Generate VOLCANO /////////////////////////////////////////////----
#New volcano function
fgsea_table <- fgsea_table[fgsea_table$padj<0.05,]
genes_lunglist <- list(vegf_genes=c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1","Flt4", "Nrp1", "Nrp2", 'KdrExon3', 'KdrExon30','Kdr'),
                        apoptosis_genes= c( 'Birc5','Brca1','Cdc25b', 'Casp9', 'Bik','Atf3', 'Txnip', 'Tspo', 'Gsr', 'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax', 'Gadd45a'),
                        tipcell_markers = c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", "Aqp1", "Apln", "Dll4", "Spry4"),
                        veins_genes = c('Nr2f2', 'Fbln2', 'Igf1', 'Vwf', 'Igf1', 'Calcrl', 'Cd59a'))

cols_volcano <- c("#6B4795",'#5D75B2', "#EA634C", "pink", "#31a583",
                  'orange4', "#B366FF",
                  "#F49739","#61A9DB")

generate_volcano_plot(degs_table = degs_lung, fgsea_table = fgsea_table, gene_list_max5 = genes_lunglist,
                      title_plot = 'lung Long Term', output_file = 'VolcanoLongTerm_lung_NoBoxes.pdf', cols = cols_volcano)




#//////////////Heatmap for selected genes ////////////////------
#Genes selected heatmaps

vegf_genes <- c("Vegfa", "Vegfb", "Vegfc",  "Pgf", "Flt1", "Flt4", "Nrp1", "Nrp2")
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, rds_object =lung.long,
                                           first_var = 'genotype', ident_1 ="LongTerm_Kdr" ,lim_minus = -2, lim_max = 2,
                                           title = 'VEGF pathway genes (Long Term)',order_genes_name = T,
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'VEGF_pathway_Heatmap', w=1)
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, rds_object =lung.long,second_var = 'celltypesc',
                                           first_var = 'genotype', ident_1 ="LongTerm_Kdr" ,lim_minus = -2, lim_max = 2,
                                           title = 'VEGF pathway genes (Long Term)',order_genes_name = T,long_factor = 5,
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'VEGF_pathway_Heatmap_PerCelltype', w=3)

apoptosis_genes <- c( 'Birc5','Brca1','Cdc25b', 'Casp9', 'Bik','Top2a',
                      'Atf3', 'Txnip', 'Tspo', 'Gsr', 'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax', 'Gadd45a')
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = apoptosis_genes, rds_object =lung.long,lim_minus = -2, lim_max = 2,
                                           first_var = 'genotype', ident_1 ="LongTerm_Kdr" ,title = 'Apoptosis marker genes',
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'ApoptosisMarkers_Heatmap', w=1)

tipcell_markers <- c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", "Aqp1", "Apln", "Dll4", "Spry4")
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = tipcell_markers, rds_object =lung.long,lim_minus = -2, lim_max = 2,
                                           first_var = 'genotype', ident_1 ="LongTerm_Kdr" ,title = 'Tip cell genes',
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'TipCellMakers_Heatmap', w=1)

#Per cell type vein markers
veins_genes <- c('Nr2f2', 'Fbln2', 'Vwf', 'Vegfc', 'Car8', 'Cpe', 'Col14a1', 'Pgm5')
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = veins_genes, rds_object = lung.long,second_var = 'celltypesc',
                                           first_var = 'genotype', ident_1 ="LongTerm_Kdr" ,lim_minus = -3, lim_max = 3,
                                           title = 'Vein genes (Long Term)',order_genes_name = T,long_factor = 3,
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'VeinsGenes_Heatmap_PerCelltype_Scale3_1st', w=2)



