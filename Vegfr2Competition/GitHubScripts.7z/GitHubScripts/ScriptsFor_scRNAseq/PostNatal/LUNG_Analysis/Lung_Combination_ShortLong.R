#Combine the two samples long and short term analysis of lung
library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(pheatmap)
library(SCpubr)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/2410_scRNA_AplnEMT_Kdr_P8_Postnatal/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/2410_scRNA_AplnEMT_Kdr_P8_Postnatal/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/2410_scRNA_AplnEMT_Kdr_P8_Postnatal/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')

#Colors for graphs
Colors_1to15 <-  c(
  '0' = 'grey',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#FFCC66", # Coral
  '13' = "#66D9D9", # Light Cyan
  '14' = "#F2A766", # Light Copper
  '15' = "#D88A6D"  # Light Brown
)

lung_cols <-c('Cap'="#FFCC66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
              'Arteries'="#ec245b","Car4+High"="#B366FF", "Car4+Low" ="#e7d6f9" , "Prol-G2Mphase"='#0fc082',
              "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue')
rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")

#START

comb.lung <- JoinLayers(comb.lung)
comb.lung <- NormalizeData(comb.lung, normalization.method = "LogNormalize", scale.factor = 10000)
comb.lung <- subset(comb.lung, subset = nFeature_RNA > 500 & nFeature_RNA < 6000 &  nCount_RNA > 2000 & nCount_RNA < 30000)
comb.lung <- subset(comb.lung, subset= Cdh5>0.1 & Ptprc<0.1)
comb.lung <- NormalizeData(comb.lung, normalization.method = "LogNormalize", scale.factor = 10000)
comb.lung <- FindVariableFeatures(comb.lung, selection.method = "vst")
comb.lung <- ScaleData(comb.lung) 
comb.lung <- RunPCA(comb.lung ) 
ElbowPlot(comb.lung, ndims = 70, reduction = 'pca')
Idents(comb.lung) <- 'experiment'
comb.lung <- RunHarmony(comb.lung, "experiment", plot_convergence = TRUE)
a<-DimPlot(comb.lung, reduction = "pca", pt.size = 1, group.by = "experiment", shuffle = T )+
  ggtitle('No HARMONY')+theme(legend.position = 'bottom')
b<-DimPlot(comb.lung, reduction = "harmony", pt.size = 1, group.by = "experiment", shuffle = T)+
  ggtitle('HARMONY')+theme(legend.position = 'none')
grid.arrange(a, b, ncol=2)

setwd(pathtosave)
# First clusterization
comb.lung <- FindNeighbors(comb.lung, dims = 1:29, reduction="harmony")
comb.lung <- FindClusters(comb.lung, resolution = 0.8, cluster.name = 'res0.8lung')
comb.lung<-RunUMAP(comb.lung, dims = 1:29,  reduction.name = "dim29lung",return.model = T, reduction = 'harmony')
lung_degs <- FindAllMarkers(comb.lung, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
lung_top10 <- lung_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.lung, reduction = 'dim29lung', group.by = 'res0.8lung', 
           cols = Colors_1to15, label = T, label.box = T)
b<-dittoBarPlot(comb.lung, var = 'res0.8lung', group.by = 'genotype.x', color.panel = Colors_1to15)
c<-DotPlot(comb.lung, features = unique(lung_top10$gene), group.by = 'res0.8lung')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
mt <- rbind(c(1,1,2,2,NA), c(1,1,2,2,NA),c(1,1,2,2,NA),c(1,1,2,2,NA),c(1,1,2,2,NA),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c, layout_matrix=mt))
dev.off()
saveRDS(comb.lung, file='CombinedShortLong_Lung.rds')


#Remove clusters 10, 11 and 12 as doublets
comb.lung2 <- subset(comb.lung, idents=c('10', '11', '12'), invert=T)
#Second clusterization
comb.lung2 <- NormalizeData(comb.lung2, normalization.method = "LogNormalize", scale.factor = 10000)
comb.lung2 <- subset(comb.lung2, subset = nFeature_RNA > 500 & nFeature_RNA < 6000 &  nCount_RNA > 2000 & nCount_RNA < 30000)
comb.lung2 <- subset(comb.lung2, subset= Cdh5>0.1 & Ptprc<0.1)
comb.lung2 <- NormalizeData(comb.lung2, normalization.method = "LogNormalize", scale.factor = 10000)
comb.lung2 <- FindVariableFeatures(comb.lung2, selection.method = "vst")
comb.lung2 <- ScaleData(comb.lung2) 
comb.lung2 <- RunPCA(comb.lung2 ) # use this genes to reduce tech variability among ports of my samples
ElbowPlot(comb.lung2, ndims = 70, reduction = 'pca')
comb.lung2 <- FindNeighbors(comb.lung2, dims = 1:29, reduction="harmony")
comb.lung2 <- FindClusters(comb.lung2, resolution = 1.3, cluster.name = 'res1.3lung2')
comb.lung2<-RunUMAP(comb.lung2, dims = 1:29,  reduction.name = "dim29lung2",return.model = T, reduction = 'harmony')
lung_degs <- FindAllMarkers(comb.lung2, logfc.threshold = 1.3, min.pct = 0.7, only.pos = T, densify = T)
lung_top10 <- lung_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.lung2, reduction = 'dim29lung2', group.by = 'res1.3lung2', 
           cols = Colors_1to15, label = T, label.box = T)
b<-dittoBarPlot(comb.lung2, var = 'res1.3lung2', group.by = 'genotype.x', color.panel = Colors_1to15)
c<-DotPlot(comb.lung2, features = unique(lung_top10$gene), group.by = 'res1.3lung2')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
mt <- rbind(c(1,1,2,2,NA), c(1,1,2,2,NA),c(1,1,2,2,NA),c(1,1,2,2,NA),c(1,1,2,2,NA),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined2.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c, layout_matrix=mt))
dev.off()

#Rename clusters and genotypes
Idents(comb.lung2) <- 'genotype.x'
levels(Idents(comb.lung2)) <- c('LongTerm_Ctrl', 'LongTerm_Kdr', 'ShortTerm_Ctrl', 'ShortTerm_Kdr')
comb.lung2$genotype <- Idents(comb.lung2)

new_names <- c('Cap', 'Cap', 'Cap', 'Car4+Low', 'Prol-Sphase',
               'Prol-G2Mphase', 'Veins', 'Car4+High', 'ArtCap', 'Arteries', 'Prol-G2Mphase', 'VeinCap', 'Car4+High')
Idents(comb.lung2) <-'res1.3lung2'
levels(Idents(comb.lung2)) <-new_names
comb.lung2$celltypesc <- Idents(comb.lung2)
comb.lung2$celltypesc <- factor(comb.lung2$celltypesc, levels=c('Arteries', 'ArtCap', 'Cap', 'Car4+High', 'Car4+Low',
                                                                'Prol-Sphase', 'Prol-G2Mphase', 'VeinCap', 'Veins'))
Idents(comb.lung2) <- 'celltypesc'
lung_degs <- FindAllMarkers(comb.lung2, logfc.threshold = 1.3, min.pct = 0.7, only.pos = T, densify = T)
lung_top10 <- lung_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)

#plot UMAP to see cluster distribution in space.
Idents(comb.lung2) <-'genotype'
a<-DimPlot(subset(comb.lung2, downsample=1125), reduction = 'dim29lung2', group.by = 'celltypesc', 
           cols = lung_cols, split.by = 'genotype')
b<-dittoBarPlot(comb.lung2, var = 'celltypesc', group.by = 'genotype', color.panel = lung_cols)
c<-DotPlot(comb.lung2, features = unique(lung_top10$gene), group.by = 'celltypesc')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
mt <- rbind(c(1,1,1,2,2), c(1,1,1,2,2),c(1,1,1,2,2),c(1,1,1,2,2),c(1,1,1,2,2),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined3.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c, layout_matrix=mt))
dev.off()

#Generate experiment_simple and genotype_simple variables
Idents(comb.lung2) <- 'genotype'
levels(Idents(comb.lung2)) <- c('LongT', 'LongT', 'ShortT', 'ShortT')
comb.lung2$experiment_simple <- Idents(comb.lung2)
Idents(comb.lung2) <- 'genotype'
levels(Idents(comb.lung2)) <- c('Ctrl', 'KdrKO', 'Ctrl', 'KdrKO')
comb.lung2$genotype_simple <- Idents(comb.lung2)

#Save final RDS file
saveRDS(comb.lung2, file='CombinedShortLong_Lung_v2.rds')
