#Combine the two samples long and short term analysis of lung
library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(ggrepel)
library(cowplot)
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(pheatmap)
library(SCpubr)
library(UpSetR)
library(ggVennDiagram)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_VolcanoPlot.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Degs_Table_PerCellType.R')

#Colors for graphs
Colors_1to15 <-  c(
  '0' = 'grey',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#FFCC66", # Coral
  '13' = "#66D9D9", # Light Cyan
  '14' = "#F2A766", # Light Copper
  '15' = "#D88A6D"  # Light Brown
)

lung_cols <-c('Cap'="#FFCC66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
              'Arteries'="#ec245b","Car4+High"="#B366FF", "Car4+Low" ="#e7d6f9" , "Prol-G2Mphase"='#0fc082',
              "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue')

lung_cols_ord <-c('Arteries'="#ec245b",'ArtCap'='#ee9db3','Cap'="#FFCC66",'VeinCap'='lightblue', 'Veins'='#6699FF',
              "Car4+High"="#B366FF", "Car4+Low" ="#e7d6f9" ,"Prol-Sphase"='#72e9c0', "Prol-G2Mphase"='#0fc082')
rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")

#Start the analysis from the comb.lung 
Idents(comb.lung) <- 'experiment_simple'
levels(comb.lung)
lung.short <- subset(comb.lung, ident='ShortT')

# ////////////////////////// Markers per cell type for dotplot /////////////////-----
#Combined markers for the dotplot (this dot plot is shared among short term and long term samples and will be shown once to identify the cell type markers)
Idents(comb.lung) <- 'celltypesc'
lung_degs <- FindAllMarkers(comb.lung, logfc.threshold = 1.3, min.pct = 0.7, only.pos = T, densify = T)
lung_top10 <- lung_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
lung_degs_lessrestrict <- FindAllMarkers(comb.lung, logfc.threshold =0.5, min.pct = 0.7, only.pos = T, densify = T)
lung_top10_lr <- lung_degs_lessrestrict %>% group_by(cluster) %>% top_n(10, avg_log2FC)

a<-DotPlot(comb.lung, features = unique(lung_top10$gene), group.by = 'celltypesc')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'), axis.title = element_blank())
cairo_pdf(filename = 'Dotplot_CelltypeMarkers.pdf', width = 15, height = 4)
a
dev.off()
cluster_separations <- c(10.5,19.5,28.5,38.5,47.5,54.5,61.5,72.5,82.5)
cluster_boxes <- data.frame(
  xmin =  c(0.5, cluster_separations[-length(cluster_separations)]),  # Start of each cluster
  xmax = cluster_separations,  # End of each cluster
  ymin = Inf,   # Extends full y-axis
  ymax = 9.3,    
  fill = lung_cols_ord # Custom colors per cluster
)
a<-DotPlot(comb.lung, features = unique(lung_top10_lr$gene), group.by = 'celltypesc', col.min = 0)&
  scale_colour_gradientn(colours = rz_palette)&ggtitle('Top gene markers per cluster')&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'), axis.title = element_blank())&
  geom_rect(data = cluster_boxes, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill), 
            alpha =1, inherit.aes = FALSE) &
  geom_vline(xintercept = c(10.5,19.5,28.5,38.5,47.5,61.5,72.5,82.5), linetype = "dashed", color = "black", size = 0.5)&
  scale_fill_identity()
cairo_pdf(filename = 'Dotplot_CelltypeMarkers.pdf', width = 19, height = 5)
a
dev.off()

# ////////////////////////////////////// Deletion plots and tables /////////////////----
#Do deletion plots and data
lung.short$kdr_exon30Norm[is.na(lung.short$kdr_exon30Norm)] <-0
lung.short$kdr_exon3Norm[is.na(lung.short$kdr_exon3Norm)] <- 0

a<-DotPlot(lung.short, features = c('kdr_exon30Norm', 'kdr_exon3Norm', 'Kdr'), group.by = 'genotype', scale = F)
a <- a$data
a<- a%>% arrange(features.plot)
a$avg_pct <- a$avg.exp*a$pct.exp
write.csv(a, file='Deletion_Summary.csv')

#Plot violin of deletion and dotplot
Idents(lung.short) <- 'genotype'
a<-VlnPlot(lung.short, group.by = 'genotype',ncol = 1, features = c('kdr_exon30Norm'), cols = c('ShortTerm_Ctrl'='#0fc082', 'ShortTerm_Kdr'='#FF6666', 'ShortTerm_KdrTomNeg'='pink'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=6), axis.title = element_blank(), legend.position = 'none', title = element_text(size=10))
b<-VlnPlot(lung.short, group.by = 'genotype',ncol = 1, features = c('kdr_exon3Norm'), cols = c('ShortTerm_Ctrl'='#0fc082', 'ShortTerm_Kdr'='#FF6666', 'ShortTerm_KdrTomNeg'='pink'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=6), axis.title = element_blank(), legend.position = 'none',  title = element_text(size=10))
c<-DotPlot(lung.short, features = c('kdr_exon3Norm', 'kdr_exon30Norm'), group.by = 'genotype', scale = F, col.min = 0,scale.max = 100, dot.scale = 10)&
  scale_color_gradientn(colors = rz_palette)&coord_flip()&
  theme(legend.position = 'right', axis.title = element_blank(),axis.text.y = element_text(angle=90, hjust = 0.5),
        legend.key.size = unit(0.3, 'cm'), axis.text.x = element_text(size=7),
        legend.text = element_text(size = 5), 
        legend.spacing.x = unit(0.3, 'cm'), legend.title = element_text(size=5))
mt <- rbind(c(1,3,NA,NA), c(2,3,NA,NA))
cairo_pdf(filename = 'Vlnplot_DeletionKdr_DotplotCombined.pdf', width = 4, height = 5)
grid.arrange(a,b,c,layout_matrix=mt)
dev.off()

#////////////////////////////////// Summaries with UMAP and Barplots ///////////////////////----
#Barplot of log2 FC to see better the differences
Idents(lung.short) <- 'genotype'
a<-DimPlot(lung.short, reduction = 'dim29lung2', group.by = 'celltypesc', pt.size = 0.5,
           cols = lung_cols, split.by = 'genotype')+theme(legend.position = 'none',  plot.title = element_blank())
Idents(lung.short) <- 'celltypesc'
alf<-sort(levels(lung.short))
real <-levels(lung.short)
reorder<-as.numeric(factor(real, levels = alf))
Idents(lung.short) <- 'genotype'
b<-dittoBarPlot(lung.short, var = 'celltypesc', group.by = 'genotype', color.panel = lung_cols, var.labels.reorder = reorder)+
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5), axis.title.x = element_blank())+ggtitle('ECs subtypes Lung')
s<-b$data
celltype_names <-unique(s$label)
results_table <- data.frame()
for (cell in celltype_names){
  mut <- s[s$label==cell & s$grouping=='ShortTerm_Ctrl',]
  ctrl<-s[s$label==cell & s$grouping=='ShortTerm_Kdr',]
  ratio <- mut$percent/ctrl$percent
  log2fc <- log2(ratio)
  results_table <- rbind(results_table, data.frame(CellType = cell, Ratio = ratio, Log2Ratio=-log2fc))
}
results_table <-results_table[reorder,]
results_table$CellType <- factor(results_table$CellType, levels = results_table$CellType)
d<- ggplot(data = results_table, aes(y = Log2Ratio, x = CellType, fill = Log2Ratio > 0)) +  
  geom_col() +  
  scale_fill_manual(values = c("FALSE" = '#0fc082', "TRUE" = 'tomato')) +  # Assign colors
  theme_minimal() + scale_y_continuous(limits = c(-2,2)) +
  labs(title = "Log2 Ratio by Cell Type", y = "Log2 Ratio", x = "Cell Type") +
  theme(axis.text.y = element_text(face = "italic"),
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title.x = element_blank()) +
  guides(fill = "none")  # Removes legend if not needed
c<-DimPlot(lung.short, reduction = 'dim29lung2', group.by = 'genotype',shuffle = T,pt.size = 0.5,
           cols = c('ShortTerm_Ctrl'='#0fc082', 'ShortTerm_Kdr'='#FF6666'))+
  theme(legend.position = 'bottom', axis.title = element_blank())+ggtitle('UMAP KdrKO vs Ctrl distribution')

mt <- rbind(c(1,1,1,1,1,2,2,2,3,3,3,4,4,NA,NA))
cairo_pdf(filename = 'Summary_UMAP_Barplot_SecondOption.pdf', width = 15, height =4)
print(grid.arrange(a,b,c,d, layout_matrix=mt))
dev.off()

#///////////////// Extraction of DEGs and filtering ///////////////////////////////////////////////////////----
#Filter possible contaminant genes
filter_results_lung <- FilterLowExpressionGenes_onlytable(lung.short, filt_th = 1.7, min_cells = 10)
genes_selected <- filter_results_lung$genes_filtered
tablesum <- filter_results_lung$gene_per
write.csv(tablesum, file='FilterGenes_LungSkewness.csv')

Idents(lung.short) <- 'genotype'
levels(lung.short)
short_kdr <- subset(lung.short, idents='ShortTerm_Kdr')
short_ctrl <- subset(lung.short, idents='ShortTerm_Ctrl')
Idents(short_kdr) <- 'sex.x'
Idents(short_ctrl) <- 'sex.x'
short_kdr <- subset(short_kdr, downsample=788)
short_ctrl <- subset(short_ctrl, downsample=726)
short_lung <- merge(short_ctrl, short_kdr)
short_lung <- JoinLayers(short_lung)
short_lung$celltypesc <- factor(short_lung$celltypesc, levels=levels(comb.lung$celltypesc))
Idents(short_lung) <- 'genotype'

#Find top DEGs per genotype
degs_lung <- FindMarkers(short_lung, ident.1 = "ShortTerm_Kdr" , ident.2 ="ShortTerm_Ctrl", min.pct = 0.05, features = genes_selected, densify = T)
degs_lung$gene <- rownames(degs_lung)
degs_lung <- rbind(degs_lung, Kdr_values)
write.csv(degs_lung, file='DEGs_PerGenotype_FilteredSkewness.csv')

#Filter genes that are not significant or not expressed at all in the control.
degs_lung_p <- degs_lung[degs_lung$p_val_adj<0.05 &degs_lung$pct.1>0.05 & degs_lung$pct.2>0.05,]

degs_lung_fc <-degs_lung_p[abs(degs_lung_p$avg_log2FC)>1,]  #Old filter and 1 of logfc
degs_lung_fc_new <-degs_lung[abs(degs_lung$avg_log2FC)>0.5 & degs_lung$p_val_adj<0.05&degs_lung$pct.2>0.02 & degs_lung$pct.1>0.02,] #fold change and pval with lower filter 
degs_lung_fc_all <-degs_lung[abs(degs_lung$avg_log2FC)>0.5 & degs_lung$pct.2>0.02 & degs_lung$pct.1>0.02,]#fold change WITHOUT pval with lower filter 

degs_lung_cl <-degs_lung[degs_lung$pct.2>0.05 & degs_lung$pct.1>0.05,] #Filter low/background expressing genes
degs_lung_cl_new <-degs_lung[degs_lung$pct.2>0.02 & degs_lung$pct.1>0.02,]

degs_lung_fc_old_all <- degs_lung_cl[abs(degs_lung_cl$avg_log2FC)>0.5,]
degs_lung_fc05_old <- degs_lung_p[abs(degs_lung_p$avg_log2FC)>0.5,]

# ///////////////////////// HEATMAP and fGSEA for all DEGs ///////////////////////////////////----
#Plot heatmaps of DEGs among cell types with more than 1 of FC
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = degs_lung_fc$gene, rds_object = short_lung, first_var = 'genotype',
                                           second_var = 'celltypesc', ident_1 ="ShortTerm_Kdr" ,title = 'DEGs with >1 abs(logFC)',
                                           ident_2 = "ShortTerm_Ctrl", name_pdf = 'TopDEGs_1FC', w=7)


# Generate fgsea plot using the function and a clean set of DEGs with p_val and percentage filter

FGSEA_Table_Plot(degs_lung_cl, extra_name = 'Lung_DEGs_ShorTermMutvsCtrl_Min5Percent_SignificantH', min_size = 10, filter_pval = T)

# ////////////////////////Generate VOLCANO /////////////////////////////////////////////-----

#Volcano with function
fgsea_table <- fgsea_table[fgsea_table$padj<0.05,]
apoptosis_hallmarkgenes <-trimws(unlist(strsplit(fgsea_table[6, 9], ",")))
genes_list <- list(VEGF= c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1","Flt4", "Nrp1", "Nrp2", 'KdrExon3', 'KdrExon30'),
                   Apoptosis= c( 'Birc5','Casp9', 'Bik','Txnip', 'Tspo', 'Gsr', 'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax', apoptosis_hallmarkgenes),
                   Tip_markers= c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", "Aqp1", "Apln", "Dll4", "Spry4"))

generate_volcano_plot(fgsea_table = fgsea_table, degs_table = degs_lung, gene_list_max5 = genes_list,pct_min = 0.05,
                      output_file = 'VolcanoPlot_MinPCT05.pdf',title_plot = 'Lung Short Term', logfc_cutoff = 0.3, cols = cols_volcano)


#//////////////Heatmap for selected genes ////////////////------
#Plot heatmaps of selected genes
tipcell_markers <- c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", "Aqp1", "Apln", "Dll4", "Spry4")
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = tipcell_markers, rds_object = short_lung,lim_minus = -2, lim_max = 2,
                                           first_var = 'genotype', ident_1 ="ShortTerm_Kdr" ,title = 'Tip cell genes',
                                           ident_2 = "ShortTerm_Ctrl", name_pdf = 'TipCellMakers_Heatmap', w=1)

apoptosis_genes<-c( 'Birc5','Casp9', 'Bik','Txnip', 'Tspo', 'Gsr', 'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax',apoptosis_hallmarkgenes)
apoptosis_lung <- c("Atf3", "Hspb1", "Ier3", "Casp9", "Birc5", "F2r", "Bik", 
                    "Cdkn1a", "Plat", "Timp1", "Rhob", "Tnfrsf12a", "Jun", 
                    "Tspo", "Bcl2", "Casp3")


generate_heatmap_fromGenesFC_mutiplegroups(gene_list = apoptosis_lung, rds_object = short_lung,lim_minus = -2, lim_max = 2,
                                           first_var = 'genotype', ident_1 ="ShortTerm_Kdr" ,title = 'Apoptosis genes',
                                           ident_2 = "ShortTerm_Ctrl", name_pdf = 'ApoptosisMakers_Heatmap', w=1)

vegf_genes <- c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1",  "Flt4", "Nrp1", "Nrp2")
#One column
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, rds_object = short_lung,
                                           first_var = 'genotype', ident_1 ="ShortTerm_Kdr" ,lim_minus = -2, lim_max = 2,
                                           title = 'VEGF pathway genes (Short Term)',order_genes_name = T,
                                           ident_2 = "ShortTerm_Ctrl", name_pdf = 'VEGF_pathway_Heatmap', w=1)
#Per cell type
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, rds_object = short_lung,second_var = 'celltypesc',
                                           first_var = 'genotype', ident_1 ="ShortTerm_Kdr" , lim_minus = -2, lim_max = 2,
                                           title = 'VEGF pathway genes (Short Term)',order_genes_name = T,long_factor = 5,
                                           ident_2 = "ShortTerm_Ctrl", name_pdf = 'VEGF_pathway_Heatmap_PerCelltype', w=3)

#Per cell type vein markers
veins_genes <- c('Nr2f2', 'Fbln2', 'Vwf', 'Vegfc', 'Car8', 'Cpe', 'Col14a1', 'Pgm5')
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = veins_genes, rds_object = short_lung,second_var = 'celltypesc',
                                           first_var = 'genotype', ident_1 ="ShortTerm_Kdr" ,lim_minus = -3, lim_max = 3,
                                           title = 'Vein genes (Short Term)',order_genes_name = T,long_factor = 3,
                                           ident_2 = "ShortTerm_Ctrl", name_pdf = 'VeinsGenes_Heatmap_PerCelltype_Scale3', w=2)
#Per cell type
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = veins_genes, rds_object = short_lung,second_var = 'celltypesc',
                                           first_var = 'genotype', ident_1 ="ShortTerm_Kdr" , lim_minus = -2, lim_max = 2,
                                           title = 'Vein genes (Short Term)',order_genes_name = T,long_factor = 5,
                                           ident_2 = "ShortTerm_Ctrl", name_pdf = 'VeinGenes_Heatmap_PerCelltype', w=3)

