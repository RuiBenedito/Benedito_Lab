library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(Heatmap)
library(SCpubr)
library(ggVennDiagram)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_VolcanoPlot.R')

Colors_1to20 <- c(
  '0' = '#adfa36',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#66D9D9", # Light Cyan
  '13' = "#F2A766", # Light Copper
  '14' = "#D88A6D", # Light Brown
  '15' = "#C266FF", # Bright Purple
  '16' = "#FFA07A", # Light Salmon
  '17' = "#7FFFD4", # Aquamarine
  '18' = "#FFD700", # Gold
  '19' = "#DC143C", # Crimson Red
  '20' = "#00CED1"  # Dark Turquoise
)
heart_cols <-c('Cap'="#FFCC66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
               'Arteries'="#ec245b","Angio"="#B366FF", "Interferon" ="#e7d6f9" , "Prol-G2Mphase"='#0fc082',
               "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue')

rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")

comb.heart <- readRDS("S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/1_RDS_Files/Heart_Combined/Cobined_heart_v3.rds")

Idents(comb.heart) <- 'genotype'
levels(comb.heart)
long_heart <- subset(comb.heart, idents=c( "LongTerm_Ctrl","LongTerm_KdrTom"    ))

# ////////////////////////////////////// Deletion plots and tables /////////////////----
#Do deletion plots and data
long_heart$kdr_exon3Norm[is.na(long_heart$kdr_exon3Norm)] <-0
long_heart$kdr_exon30Norm[is.na(long_heart$kdr_exon30Norm)]<-0
a<-DotPlot(long_heart, features = c('kdr_exon30Norm', 'kdr_exon3Norm', 'Kdr'), group.by = 'genotype', scale = F)
a <- a$data
a<- a%>% arrange(features.plot)
write.csv(a, 'DeletionExpression.csv')

#Plot violin of deletion and dotplot
Idents(long_heart) <- 'genotype'
a<-VlnPlot(subset(long_heart, downsample= 1513), group.by = 'genotype',ncol = 1, features = c('kdr_exon30Norm'), cols = c('LongTerm_Ctrl'='#0fc082', 'LongTerm_KdrTom'='#FF6666', 'ShortTerm_KdrTomNeg'='pink'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=6), axis.title = element_blank(), legend.position = 'none', title = element_text(size=10))
b<-VlnPlot(subset(long_heart, downsample= 1513), group.by = 'genotype',ncol = 1, features = c('kdr_exon3Norm'), cols = c('LongTerm_Ctrl'='#0fc082', 'LongTerm_KdrTom'='#FF6666', 'ShortTerm_KdrTomNeg'='pink'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=6), axis.title = element_blank(), legend.position = 'none',  title = element_text(size=10))
c<-DotPlot(long_heart, features = c('kdr_exon3Norm', 'kdr_exon30Norm'), group.by = 'genotype', scale = F, col.min = 0, scale.max = 100, dot.scale = 10)&
  scale_color_gradientn(colors = rz_palette)&coord_flip()&
  theme(legend.position = 'right', axis.title = element_blank(),axis.text.y = element_text(angle=90, hjust = 0.5),
        legend.key.size = unit(0.3, 'cm'), axis.text.x = element_text(size=7),
        legend.text = element_text(size = 5), 
        legend.spacing.x = unit(0.3, 'cm'), legend.title = element_text(size=5))

mt <- rbind(c(1,3,NA,NA), c(2,3,NA,NA))
cairo_pdf(filename = 'Vlnplot_DeletionKdr_DotplotCombined.pdf', width = 4, height = 5)
grid.arrange(a,b,c, layout_matrix=mt)
dev.off()

#////////////////////////////////// Summaries with UMAP and Barplots ///////////////////////----

#Do summary with umap and barplots 
Idents(long_heart) <- 'genotype'
a<-DimPlot(subset(long_heart, downsample= 1513), reduction = 'dim22heart', group.by = 'celltypes', pt.size = 0.5,
           cols = heart_cols, split.by = 'genotype')+theme(legend.position = 'none',  plot.title = element_blank())
Idents(long_heart) <- 'celltypes'
alf<-sort(levels(long_heart))
real <-levels(long_heart)
reorder<-as.numeric(factor(real, levels = alf))
Idents(long_heart) <- 'genotype'
b<-dittoBarPlot(long_heart, var = 'celltypes', group.by = 'genotype', color.panel = heart_cols, var.labels.reorder = reorder)+
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5), axis.title.x = element_blank())+ggtitle('ECs subtypes heart')
c<-DimPlot(subset(long_heart, downsample= 1513), reduction = 'dim22heart', group.by = 'genotype',shuffle = T,pt.size = 0.5,
           cols = c('LongTerm_Ctrl'='#0fc082', 'LongTerm_KdrTom'='#FF6666'))+
  theme(legend.position = 'bottom', axis.title = element_blank())+ggtitle('UMAP KdrKO vs Ctrl distribution')
s<-b$data
celltype_names <-unique(s$label)
results_table <- data.frame()
for (cell in celltype_names){
  mut <- s[s$label==cell & s$grouping=='LongTerm_Ctrl',]
  ctrl<-s[s$label==cell & s$grouping=='LongTerm_KdrTom',]
  ratio <- mut$percent/ctrl$percent
  log2fc <- log2(ratio)
  results_table <- rbind(results_table, data.frame(CellType = cell, Ratio = ratio, Log2Ratio=-log2fc))
}
results_table <- results_table[reorder,]
results_table$CellType <- factor(results_table$CellType, levels = results_table$CellType)
d<- ggplot(data = results_table, aes(y = Log2Ratio, x = CellType, fill = Log2Ratio > 0)) +  
  geom_col() +  
  scale_fill_manual(values = c("FALSE" = '#0fc082', "TRUE" = 'tomato')) +  # Assign colors
  theme_minimal() + scale_y_continuous(limits = c(-2,2)) +
  labs(title = "Log2 Ratio by Cell Type", y = "Log2 Ratio", x = "Cell Type") +
  theme(axis.text.y = element_text(face = "italic"),
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title.x = element_blank()) +
  guides(fill = "none")  # Removes legend if not needed
mt <- rbind(c(1,1,1,1,1,2,2,2,3,3,3,4,4,NA,NA))
cairo_pdf(filename = 'Summary_UMAP_Barplot_SecondOption.pdf', width = 15, height =4)
print(grid.arrange(a,b,c,d, layout_matrix=mt))
dev.off()

#///////////////// Extraction of DEGs and filtering ///////////////////////////////////////////////////////----
#Filter possible contaminant genes
filter_results_heart <- FilterLowExpressionGenes_onlytable(long_heart, filt_th = 1.7, min_cells = 10)
genes_selected <- filter_results_heart$genes_filtered
tablesum <- filter_results_heart$gene_per
write.csv(tablesum, file='FilterGenes_heartSkewness.csv')

#Find DEGS per genotype
Idents(long_heart) <-'genotype'
degs_heart <- FindMarkers(long_heart, ident.1 = "LongTerm_KdrTom" , ident.2 ="LongTerm_Ctrl", min.pct = 0.05, features = genes_selected, densify = T)
degs_heart$gene <- rownames(degs_heart)
degs_heart <- rbind(degs_heart, Kdr_values)
write.csv(degs_heart, file='DEGs_PerGenotype_FilteredSkewness.csv')


#Filter genes that are not significant or not expressed at all in the control.
#clean gene set no significance or fold change selection
degs_heart_cl <-degs_heart[degs_heart$pct.2>=0.050 & degs_heart$pct.1>=0.050,] 
degs_heart_cl_new <-degs_heart[degs_heart$pct.2>=0.02 & degs_heart$pct.1>=0.02,] 
#Significance selection
degs_heart_p <- degs_heart_cl[degs_heart_cl$p_val_adj<0.05,]
degs_heart_p_new <- degs_heart_cl_new[degs_heart_cl_new$p_val_adj<0.05,]
#Fold change selection and significance
degs_heart_fc <- degs_heart_p[abs(degs_heart_p$avg_log2FC)>1,] 
degs_heart_fc2 <- degs_heart_p[abs(degs_heart_p$avg_log2FC)>0.5,] 
degs_heart_fc2_new <- degs_heart_p_new[abs(degs_heart_p_new$avg_log2FC)>0.5,] 
#Only fold change
degs_heart_fc_all <-degs_heart_cl[abs(degs_heart_cl$avg_log2FC)>0.5,]
degs_heart_fc_all_new <-degs_heart_cl_new[abs(degs_heart_cl_new$avg_log2FC)>0.5,]

# ///////////////////////// HEATMAP and fGSEA for all DEGs ///////////////////////////////////----
#Plot heatmaps of DEGs among cell types with more than 1 of FC
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = degs_heart_fc$gene, rds_object = long_heart, first_var = 'genotype',
                                           second_var = 'celltypes', ident_1 ="LongTerm_KdrTom" ,title = 'DEGs with >1 abs(logFC)',
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'TopDEGs_1FC', w=7)
# Generate fgsea plot using the function and a clean set of DEGs with p_val and percentage filter
FGSEA_Table_Plot(degs_heart_cl, extra_name = 'heart_DEGs_LongTermMutvsCtrl', min_size = 10, filter_pval = T)

# ////////////////////////Generate VOLCANO /////////////////////////////////////////////----
#New function volcano
fgsea_table <- fgsea_table[fgsea_table$padj<0.05,]
genes_heartlist <- list(vegf_genes=c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1","Flt4", "Nrp1", "Nrp2", 'KdrExon3', 'KdrExon30','Kdr'),
                        apoptosis_genes= c( 'Birc5','Brca1','Cdc25b', 'Casp9', 'Bik','Atf3', 'Txnip', 'Tspo', 'Gsr', 'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax', 'Gadd45a'),
                        tipcell_markers = c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", "Aqp1", "Apln", "Dll4", "Spry4"),
                        veins_genes = c('Nr2f2', 'Fbln2', 'Igf1', 'Vwf', 'Igf1', 'Calcrl', 'Cd59a'))

cols_volcano <- c("#6B4795",'#5D75B2', "#EA634C", "pink", "#31a583",
                  'orange4', "#B366FF",
                 "#F49739","#61A9DB")


generate_volcano_plot(degs_table = degs_heart, fgsea_table = fgsea_table, gene_list_max5 = genes_heartlist,
                      title_plot = 'Heart Long Term', output_file = 'VolcanoLongTerm_heart_NoBoxes.pdf', cols = cols_volcano)


#//////////////Heatmap for selected genes ////////////////------
# VEGF pahtway heatmapts 
vegf_genes <- c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1","Flt4", "Nrp1", "Nrp2")
#One column
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, rds_object = long_heart,
                                           first_var = 'genotype', ident_1 ="LongTerm_KdrTom" ,lim_minus = -2, lim_max = 2,
                                           title = 'VEGF pathway genes (Long Term)',order_genes_name = T,
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'VEGF_pathway_Heatmap', w=1)
#Per cell type
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, rds_object = long_heart,second_var = 'celltypes',
                                           first_var = 'genotype', ident_1 ="LongTerm_KdrTom" ,lim_minus = -2, lim_max = 2,
                                           title = 'VEGF pathway genes (Long Term)',order_genes_name = T,long_factor = 5,
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'VEGF_pathway_Heatmap_PerCelltype', w=3)
#Per cell type vein markers
veins_genes <- c('Nr2f2', 'Fbln2', 'Igf1', 'Vwf', 'Igf1', 'Calcrl')
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = veins_genes, rds_object = long_heart,second_var = 'celltypes',
                                           first_var = 'genotype', ident_1 ="LongTerm_KdrTom" ,lim_minus = -3, lim_max = 3,
                                           title = 'Vein genes (Long Term)',order_genes_name = T,long_factor = 3,
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'VeinsGenes_Heatmap_PerCelltype_NewCols', w=2)

#Tip cells heatmapts
tipcell_markers <- c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", "Aqp1", "Apln", "Dll4", "Spry4")
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = tipcell_markers, rds_object = long_heart,
                                           first_var = 'genotype', ident_1 ="LongTerm_KdrTom" ,lim_minus = -2, lim_max = 2,
                                           title = 'Tip cell pathway genes (Long Term)',
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'TipCell_pathway_Heatmap', w=1)
#Apoptosis cells heatmapts
apoptosis_genes <- c( 'Birc5','Brca1','Cdc25b', 'Casp9', 'Bik','Top2a','Atf3', 'Txnip', 'Tspo', 'Gsr', 'Timp3', 'Timp1','Tp53', 'Casp3', 'Bcl2', 'Bax', 'Gadd45a')
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = apoptosis_genes, rds_object = long_heart,
                                           first_var = 'genotype', ident_1 ="LongTerm_KdrTom" ,lim_minus = -2, lim_max = 2,
                                           title = 'Apoptosis pathway genes (Long Term)',
                                           ident_2 = "LongTerm_Ctrl", name_pdf = 'Apoptosis_pathway_Heatmap', w=1)

