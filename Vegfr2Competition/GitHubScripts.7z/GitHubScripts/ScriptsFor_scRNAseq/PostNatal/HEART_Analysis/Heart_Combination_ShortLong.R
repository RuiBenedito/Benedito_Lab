library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(Heatmap)
library(SCpubr)
library(ggVennDiagram)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')

Colors_1to20 <- c(
  '0' = '#adfa36',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#66D9D9", # Light Cyan
  '13' = "#F2A766", # Light Copper
  '14' = "#D88A6D", # Light Brown
  '15' = "#C266FF", # Bright Purple
  '16' = "#FFA07A", # Light Salmon
  '17' = "#7FFFD4", # Aquamarine
  '18' = "#FFD700", # Gold
  '19' = "#DC143C", # Crimson Red
  '20' = "#00CED1"  # Dark Turquoise
)
heart_cols <-c('Cap'="#FFCC66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
               'Arteries'="#ec245b","Angio"="#B366FF", "Interferon" ="#e7d6f9" , "Prol-G2Mphase"='#0fc082',
               "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue')


rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")


comb.heart <- JoinLayers(comb.heart)
comb.heart <- NormalizeData(comb.heart, normalization.method = "LogNormalize", scale.factor = 10000)
comb.heart <- subset(comb.heart, subset = nFeature_RNA > 500 & nFeature_RNA < 6000 &  nCount_RNA > 2000 & nCount_RNA < 30000)
comb.heart <- subset(comb.heart, subset= Cdh5>0.1 & Ptprc<0.1)
comb.heart <- NormalizeData(comb.heart, normalization.method = "LogNormalize", scale.factor = 10000)
comb.heart <- FindVariableFeatures(comb.heart, selection.method = "vst")
comb.heart <- ScaleData(comb.heart) 
comb.heart <- RunPCA(comb.heart ) # use this genes to reduce tech variability among ports of my samples
ElbowPlot(comb.heart, ndims = 50, reduction = 'pca')
Idents(comb.heart) <- 'experiment' #Variable that indicates the port of sequencing
comb.heart <- RunHarmony(comb.heart, "experiment", plot_convergence = TRUE)
a<-DimPlot(comb.heart, reduction = "pca", pt.size = 0.5, group.by = "experiment", shuffle = T )+
  ggtitle('No HARMONY')+theme(legend.position = 'bottom')
b<-DimPlot(comb.heart, reduction = "harmony", pt.size = 0.5, group.by = "experiment", shuffle = T)+
  ggtitle('HARMONY')+theme(legend.position = 'none')
cairo_pdf(filename = 'Harmony_heart.pdf', width = 15, height = 5)
print(grid.arrange(a, b, ncol=2))
dev.off()


#1st First filter to see cell types
comb.heart <- FindNeighbors(comb.heart, dims = 1:29, reduction="harmony")
comb.heart <- FindClusters(comb.heart, resolution = 0.8, cluster.name = 'res0.8heart')
comb.heart<-RunUMAP(comb.heart, dims = 1:29,  reduction.name = "dim29heart",return.model = T, reduction = 'harmony')
#Identify markers to see contaminant clusters
heart_degs <- FindAllMarkers(comb.heart, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
heart_top10 <- heart_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.heart, reduction = 'dim29heart', group.by = 'res0.8heart', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.heart, var = 'res0.8heart', group.by = 'genotype.x', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.heart, features = unique(heart_top10$gene), group.by = 'res0.8heart')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(comb.heart, features = 'Fabp4', group.by = 'res0.8heart', cols = Colors_1to20)+theme(legend.position = 'none')
d2<-VlnPlot(comb.heart, features = 'nFeature_RNA', group.by = 'res0.8heart', cols = Colors_1to20)+theme(legend.position = 'none')
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()
saveRDS(comb.heart, file='Cobined_heart_v1.rds')



#Cluster 6  endocardium (high Npr3 and low Fabp4)
#Cluster 7 are pericytes and doublets (Kcnj8 high)
#Cluster 13-17 doublets or contaminant from other tissues (Selenop/Ctsl/Aqp1)
#Cluster 12 Cardiomyocytes (High Tnn genes and Myl)
Idents(comb.heart) <- 'res0.8heart'
comb.heart2 <- subset(comb.heart, idents=c(6,7,12,13,14,15,16,17), invert=T)
#Set genotype names
Idents(comb.heart2)<-'genotype.x'
levels(Idents(comb.heart2)) <-c('ShortTerm_Ctrl', 'ShortTerm_KdrTom', 'LongTerm_Ctrl', 'LongTerm_KdrTom', 'LongTerm_KdrTom')
comb.heart2$genotype <- Idents(comb.heart2)

saveRDS(comb.heart2, file='Cobined_heart_v2.rds')


#2nd First filter to see cell types
comb.heart2 <- NormalizeData(comb.heart2, normalization.method = "LogNormalize", scale.factor = 10000)
comb.heart2 <- FindVariableFeatures(comb.heart2, selection.method = "vst")
comb.heart2 <- ScaleData(comb.heart2) 
comb.heart2 <- RunPCA(comb.heart2 )
ElbowPlot(comb.heart2, ndims = 50, reduction = 'pca')
comb.heart2 <- FindNeighbors(comb.heart2, dims = 1:29, reduction="harmony")
comb.heart2 <- FindClusters(comb.heart2, resolution = 0.8, cluster.name = 'res0.8heart2')
comb.heart2<-RunUMAP(comb.heart2, dims = 1:29,  reduction.name = "dim29heart2",return.model = T, reduction = 'harmony')
#Identify markers to see contaminant clusters
heart_degs <- FindAllMarkers(comb.heart2, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
heart_top10 <- heart_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.heart2, reduction = 'dim29heart2', group.by = 'res0.8heart2', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.heart2, var = 'res0.8heart2', group.by = 'genotype', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.heart2, features = unique(heart_top10$gene), group.by = 'res0.8heart2')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(comb.heart2, features = 'Fabp4', group.by = 'res0.8heart2', cols = Colors_1to20)+theme(legend.position = 'none')
d2<-VlnPlot(comb.heart2, features = 'Meis2', group.by = 'res0.8heart2', cols = Colors_1to20)+theme(legend.position = 'none')
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined2.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()

#Cluster 10 kidney contamination (Igfbp5+ and low Fabp4)
#Cluster 11 lung contamination (High Tmem100 and low Fabp4)
Idents(comb.heart2) <- 'res0.8heart2'
comb.heart3 <- subset(comb.heart2, idents=c(10,11), invert=T)

#normalize reads of floxed exons
comb.heart3$kdr_exon3Norm <- log((comb.heart3$Kdr_exon3*10^4/comb.heart3$nCount_RNA)+1)
comb.heart3$kdr_exon30Norm <- log((comb.heart3$Kdr_exon30*10^4/comb.heart3$nCount_RNA)+1)


#3rd First filter to see cell types
comb.heart3 <- NormalizeData(comb.heart3, normalization.method = "LogNormalize", scale.factor = 10000)
comb.heart3 <- FindVariableFeatures(comb.heart3, selection.method = "vst")
comb.heart3 <- ScaleData(comb.heart3) 
comb.heart3 <- RunPCA(comb.heart3 )
ElbowPlot(comb.heart3, ndims = 50, reduction = 'pca')
comb.heart3 <- FindNeighbors(comb.heart3, dims = 1:29, reduction="harmony")
comb.heart3 <- FindClusters(comb.heart3, resolution = 0.8, cluster.name = 'res0.8heart3')
comb.heart3<-RunUMAP(comb.heart3, dims = 1:29,  reduction.name = "dim29heart3",return.model = T, reduction = 'harmony')
#Identify markers to see contaminant clusters
heart_degs <- FindAllMarkers(comb.heart3, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
heart_top10 <- heart_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.heart3, reduction = 'dim29heart3', group.by = 'res0.8heart3', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.heart3, var = 'res0.8heart3', group.by = 'genotype', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.heart3, features = unique(heart_top10$gene), group.by = 'res0.8heart3')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(comb.heart3, features = 'Fabp4', group.by = 'res0.8heart3', cols = Colors_1to20)+theme(legend.position = 'none')
d2<-VlnPlot(comb.heart3, features = 'Meis2', group.by = 'res0.8heart3', cols = Colors_1to20)+theme(legend.position = 'none')
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined3.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()



#Check best dimensional reduction
Idents(comb.heart3) <- 'res0.8heart3'
levels(Idents(comb.heart3))
plots <- list()
dimensions_test <- c(24:34)
for (dim in dimensions_test){
  comb.heart3 <- FindNeighbors(comb.heart3, dims = 1:dim, reduction="harmony")
  name_red <- paste0('dim', dim, 'heart')
  comb.heart3<-RunUMAP(comb.heart3, dims = 1:dim,  reduction.name = name_red,return.model = T, reduction = 'harmony')
  plots[[dim]] <-DimPlot(comb.heart3, reduction = name_red, group.by = 'res0.8heart3', 
                         cols = Colors_1to20, label = T, label.box = T)
}
cairo_pdf(filename = 'UMAP_DifferentDimensions_heart.pdf', width = 20, height = 15)
plot_grid(plotlist= plots[24:34])
dev.off()

#Change name of selected reduction
names(comb.heart3@reductions)[3]<- 'dim29_selected'

#Increase resolution
comb.heart3 <- FindClusters(comb.heart3, resolution = 0.8, cluster.name = 'res0.8heart3')
comb.heart3 <- FindClusters(comb.heart3, resolution = 1.3, cluster.name = 'res1.3heart3')
Idents(comb.heart3) <-'res0.8heart3'
Idents(comb.heart3) <-'res1.3heart3'
#Identify markers to see contaminant clusters
heart_degs <- FindAllMarkers(comb.heart3, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
heart_top10 <- heart_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.heart3, reduction = 'dim29_selected', group.by = 'res0.8heart3', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.heart3, var = 'res0.8heart3', group.by = 'genotype', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.heart3, features = unique(heart_top10$gene), group.by = 'res0.8heart3')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(comb.heart3, features = 'Fabp4', group.by = 'res0.8heart3', cols = Colors_1to20)+theme(legend.position = 'none')
d2<-VlnPlot(comb.heart3, features = 'nCount_RNA', group.by = 'res0.8heart3', cols = Colors_1to20)+theme(legend.position = 'none')
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined4.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()

#Cluster 9 is contamination from myocardial cells
Idents(comb.heart3) <-'res0.8heart3'
comb.heart4 <- subset(comb.heart3, idents=c(9,11), invert=T)

comb.heart4 <- NormalizeData(comb.heart4, normalization.method = "LogNormalize", scale.factor = 10000)
comb.heart4 <- FindVariableFeatures(comb.heart4, selection.method = "vst")
comb.heart4 <- ScaleData(comb.heart4) 
comb.heart4 <- RunPCA(comb.heart4 ) 
ElbowPlot(comb.heart4, ndims = 50, reduction = 'pca')
comb.heart4 <- FindNeighbors(comb.heart4, dims = 1:29, reduction="harmony")
comb.heart4 <- FindClusters(comb.heart4, resolution = 0.8, cluster.name = 'res0.8heart4')
comb.heart4<-RunUMAP(comb.heart4, dims = 1:29,  reduction.name = "dim29heart4",return.model = T, reduction = 'harmony')
#Identify markers to see contaminant clusters
heart_degs <- FindAllMarkers(comb.heart4, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
heart_top10 <- heart_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.heart4, reduction = 'dim26heart_selected', group.by = 'res0.8heart4', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.heart4, var = 'res0.8heart4', group.by = 'genotype', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.heart4, features = unique(heart_top10$gene), group.by = 'res0.8heart4')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(comb.heart4, features = 'Fabp4', group.by = 'res0.8heart4', cols = Colors_1to20)+theme(legend.position = 'none')
d2<-VlnPlot(comb.heart4, features = 'Meis2', group.by = 'res0.8heart4', cols = Colors_1to20)+theme(legend.position = 'none')
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined5.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()

#Check best dimensional reduction
Idents(comb.heart4) <- 'res0.8heart3'
levels(Idents(comb.heart4))
plots <- list()
dimensions_test <- c(20:23)
for (dim in dimensions_test){
  comb.heart4 <- FindNeighbors(comb.heart4, dims = 1:dim, reduction="harmony")
  name_red <- paste0('dim', dim, 'heart')
  comb.heart4<-RunUMAP(comb.heart4, dims = 1:dim,  reduction.name = name_red,return.model = T, reduction = 'harmony')
  plots[[dim]] <-DimPlot(comb.heart4, reduction = name_red, group.by = 'res0.8heart3', 
                         cols = Colors_1to20, label = T, label.box = T)
}
cairo_pdf(filename = 'UMAP_DifferentDimensions_heart2.pdf', width = 20, height = 15)
plot_grid(plotlist= plots[20:23])
dev.off()

#Best is 26 dim
names(comb.heart4@reductions)[8] <- 'dim26heart_selected'


#Rename clusters
Idents(comb.heart4) <-'res0.8heart4'
heart_names <-c('Cap', 'Cap', 'Prol-Sphase', 'Angio', 'Veins','Cap', 'ArtCap', 'ArtCap', 'Prol-G2Mphase','Interferon', 'Arteries')
levels(Idents(comb.heart4)) <-heart_names
comb.heart4$celltypes <- Idents(comb.heart4)


#Identify markers to see contaminant clusters
Idents(comb.heart4) <-'celltypes'
heart_degs <- FindAllMarkers(comb.heart4, logfc.threshold = 1, min.pct = 0.7, only.pos = T, densify = T)
heart_top10 <- heart_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)

#Plot summary 4
Idents(comb.heart4)<-'genotype'
a<-DimPlot(comb.heart4, reduction = 'dim22heart', group.by = 'celltypes', 
           cols = heart_cols, label = T, label.box = T)
b<-dittoBarPlot(comb.heart4, var = 'celltypes', group.by = 'genotype', color.panel = heart_cols)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.heart4, features = unique(heart_top10$gene), group.by = 'celltypes')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- VlnPlot(subset(comb.heart4, downsample=348), features = 'Kdr', group.by = 'genotype', cols = c('grey', 'pink', 'grey', 'pink'))+
  theme(legend.position = 'none', axis.title = element_blank())
d2<-VlnPlot(subset(comb.heart4, downsample=348), features = 'kdr_exon3Norm', group.by = 'genotype', cols=c('grey', 'pink', 'grey', 'pink'))+
  theme(legend.position = 'none', axis.title = element_blank())
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,4,4),c(1,1,2,5,5),c(1,1,2,5,5),c(1,1,2,5,5),
            c(NA,NA,NA,NA,NA),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined6.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d,d2, layout_matrix=mt))
dev.off()



comb.heart4$celltypes <- factor(comb.heart4$celltypes, levels=c("Arteries" ,"ArtCap"  , "Cap" , "VeinCap" ,"Veins",
                                                                "Interferon" ,"Angio","Prol-Sphase" ,"Prol-G2Mphase"))

Idents(comb.heart4) <- 'Sample'
levels(Idents(comb.heart4)) <- c('Female', 'Male', 'Male', 'Female', 'Female','Female','Female')
comb.heart4$sex.x <- Idents(comb.heart4)

#Save final RDS file
saveRDS(comb.heart4, file='Cobined_heart_v3.rds')
