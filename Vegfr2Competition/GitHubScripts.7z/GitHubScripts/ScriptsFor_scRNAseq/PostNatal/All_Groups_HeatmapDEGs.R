#Plot all genes fc 
library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(SCpubr)
library(ggVennDiagram)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')


rz_pallete <-  c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")
#Select short term subsets
Idents(comb.brain) <- 'genotype'
short_brain<- subset(comb.brain, idents= c( "ShortTerm_Ctrl", "ShortTerm_KdrTom"))
Idents(comb.heart) <- 'genotype'
short_heart<- subset(comb.heart, idents= c( "ShortTerm_Ctrl", "ShortTerm_KdrTom"  ))

Idents(comb.lung) <- 'genotype'
levels(Idents(comb.lung)) <- c( "LongTerm_Ctrl" , "LongTerm_KdrTom" ,  "ShortTerm_Ctrl" ,"ShortTerm_KdrTom" )
comb.lung$genotype <- Idents(comb.lung) #correct for the names so they can be subseted together 
Idents(comb.lung) <- 'genotype'
short_lung <- subset(comb.lung, ident=c("ShortTerm_Ctrl" ,"ShortTerm_KdrTom" ))

#Select long term subsets
Idents(comb.brain) <- 'genotype'
long_brain<- subset(comb.brain, idents= c( "LongTerm_Ctrl" , "LongTerm_KdrTom" ))
Idents(comb.heart) <- 'genotype'
long_heart<- subset(comb.heart, idents= c( "LongTerm_Ctrl" , "LongTerm_KdrTom"  ))
Idents(comb.lung) <- 'genotype'
long_lung <- subset(comb.lung, ident=c( "LongTerm_Ctrl" , "LongTerm_KdrTom" ))

#combine all the short term samples
short_all <- merge(short_brain, c(short_heart, short_kidney, short_lung))
short_all <- JoinLayers(short_all)
short_all <- NormalizeData(short_all)

#combine all the long term samples
long_all <- merge(long_brain, c(long_heart, long_lung))
long_all <- JoinLayers(long_all)
long_all <- NormalizeData(long_all)
long_all <- ScaleData(long_all)


all <- merge(comb.brain, c(comb.heart, comb.lung))
all <- JoinLayers(all)
all <- NormalizeData(all)
all <- ScaleData(all)

#////////////////#////////////////#///////////////////  LONG TERM ANALYSIS ////////////////////////////////////////----
setwd(long_path)

#Filter possible contaminant genes
filter_results_all <- FilterLowExpressionGenes_onlytable(long_all, filt_th = 1.7, min_cells = 10)
genes_selected <- filter_results_all$genes_filtered
tablesum <- filter_results_all$gene_per
write.csv(tablesum, file='FilterGenes_AllSkewness.csv')

#Find general degs mut vs ctrl
all_degs <- list()
Idents(long_all) <-'tissue.x'
organs <-levels(Idents(long_all))
for (types in organs) {
  sub_obj <-subset(long_all, ident=types)
  Idents(sub_obj)<-'genotype'
  degs <- FindMarkers(sub_obj, 
                      ident.1 = "LongTerm_KdrTom" , ident.2 = "LongTerm_Ctrl"  ,
                      min.pct = 0.05, features = genes_selected, densify = T)
  degs$celltype <- types
  degs$gene <- rownames(degs)
  all_degs[[types]] <- degs
}
tab <- do.call(rbind, all_degs)
tab <- tab[tab$pct.1>0.05 & tab$pct.2>0.05,]
tab_p <- tab[tab$p_val_adj<0.05&tab$pct.1>0.05&tab$pct.2>0.05,]
tab_fc <- tab[tab$p_val_adj<0.05&tab$pct.1>0.05&tab$pct.2>0.05&abs(tab$avg_log2FC)>1,]

long_all$tissue.x <- factor(long_all$tissue.x, levels=c('Brain', 'Heart', 'Lung'))
Idents(long_all) <-'tissue.x'
levels(long_all)
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = unique(tab_fc$gene), first_var = 'genotype',lim_minus = -2, lim_max = 2,
                                           second_var = 'tissue.x', ident_1 =  "LongTerm_KdrTom",w = 7,plot_values = F,name_pdf = 'DEGs_Overall_FC1',
                                           ident_2 ="LongTerm_Ctrl",long_factor = 25 ,cr=T, cc=F, rds_object = long_all, clust_method = 'complete')

generate_heatmap_fromGenesFC_mutiplegroups(gene_list = unique(tab_p$gene), first_var = 'genotype',lim_minus = -2, lim_max = 2,
                                           second_var = 'tissue.x', ident_1 =  "LongTerm_KdrTom",w = 7,plot_values = F,name_pdf = 'DEGs_Overall_pval',
                                           ident_2 ="LongTerm_Ctrl",long_factor = 25 ,cr=T,  rds_object = long_all, clust_method = 'complete')

vegf_genes <- c("Vegfa", "Vegfb", "Vegfc", "Pgf", "Flt1",  "Flt4", "Nrp1", "Nrp2")
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = vegf_genes, first_var = 'genotype',lim_minus = -2, lim_max = 2,
                                           second_var = 'tissue.x', ident_1 = "LongTerm_KdrTom",w = 1.5,
                                           name_pdf = 'VEGF_Related_Genes',
                                           ident_2 ="LongTerm_Ctrl",order_genes_name = F,
                                           rds_object = long_all)

#///////////////////  SHORT TERM ANALYSIS ////////////////////////////////////////----
#Filter possible contaminant genes
filter_results_all <- FilterLowExpressionGenes_onlytable(short_all, filt_th = 1.7, min_cells = 10)
genes_selected <- filter_results_all$genes_filtered
tablesum <- filter_results_all$gene_per
write.csv(tablesum, file='FilterGenes_AllSkewness.csv')


#Find general degs mut vs ctrl
all_degs <- list()
Idents(short_all) <-'tissue.x'
organs <-levels(Idents(short_all))
for (types in organs) {
  sub_obj <-subset(short_all, ident=types)
  Idents(sub_obj)<-'genotype'
  degs <- FindMarkers(sub_obj, 
                      ident.1 = 'ShortTerm_KdrTom', ident.2 = 'ShortTerm_Ctrl' ,
                      min.pct = 0.05, features = genes_selected, densify = T)
  degs$celltype <- types
  degs$gene <- rownames(degs)
  all_degs[[types]] <- degs
}
tab <- do.call(rbind, all_degs)
tab <- tab[tab$pct.1>0.05 & tab$pct.2>0.05,]
tab_p <- tab[tab$p_val_adj<0.05&tab$pct.1>0.05&tab$pct.2>0.05,]
tab_fc <- tab[tab$p_val_adj<0.05&tab$pct.1>0.05&tab$pct.2>0.05&abs(tab$avg_log2FC)>1,]

short_all$tissue.x <- factor(short_all$tissue.x, levels=c('Brain', 'Heart', 'Lung', 'Kidney'))
Idents(short_all) <-'tissue.x'
generate_heatmap_fromGenesFC_mutiplegroups(gene_list = unique(tab_fc$gene), first_var = 'genotype',lim_minus = -2, lim_max = 2,pct=0.05,
                                           second_var = 'tissue.x', ident_1 = 'ShortTerm_KdrTom',w = 7,plot_values = F,name_pdf = 'DEGs_Overall_FC1',
                                           ident_2 ="ShortTerm_Ctrl",long_factor = 25 ,cr=T, cc=T, rds_object = short_all, clust_method = 'complete')

generate_heatmap_fromGenesFC_mutiplegroups(gene_list = unique(tab_p$gene), first_var = 'genotype',lim_minus = -2, lim_max = 2,pct=0.05,
                                           second_var = 'tissue.x', ident_1 = 'ShortTerm_KdrTom',w = 7,plot_values = F,name_pdf = 'DEGs_Overall_pval',
                                           ident_2 ="ShortTerm_Ctrl",long_factor = 25 ,cr=T,cc=T,  rds_object = short_all, clust_method = 'complete')


#Only short term all organs (to see Flt1 expression)

Idents(short_all) <- 'tissue.x'
levels(short_all)
short_all2<-subset(short_all, idents=c('Brain', 'Heart', 'Lung', 'Kidney'))
Idents(short_all2) <- 'tissue.x'  
a<-VlnPlot(subset(short_all2, downsample=1985), features = 'Flt1', group.by = 'tissue.x',
           cols = c( 'lightgreen', 'tomato', 'orange','lightblue'))+
  theme(axis.title.x = element_blank(), axis.text.x = element_text(angle=0, hjust=0.5), legend.position = 'none')
setwd(short_path)
cairo_pdf(file='ViolinPlot_AllSamples_Flt1Vegfr1_ShortTerm.pdf', width = 5, height = 6)
a
dev.off()