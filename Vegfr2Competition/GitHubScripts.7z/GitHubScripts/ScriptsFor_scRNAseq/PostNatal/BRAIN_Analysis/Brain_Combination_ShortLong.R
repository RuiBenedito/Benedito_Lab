library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(Heatmap)
library(SCpubr)
library(ggVennDiagram)
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')

Colors_1to20 <- c(
  '0' = '#adfa36',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#66D9D9", # Light Cyan
  '13' = "#F2A766", # Light Copper
  '14' = "#D88A6D", # Light Brown
  '15' = "#C266FF", # Bright Purple
  '16' = "#FFA07A", # Light Salmon
  '17' = "#7FFFD4", # Aquamarine
  '18' = "#FFD700", # Gold
  '19' = "#DC143C", # Crimson Red
  '20' = "#00CED1"  # Dark Turquoise
)
brain_cols <-c('Cap'="#FFCC66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
              'Arteries'="#ec245b","Act"="#B366FF", "Choroid-plexus" ="#e7d6f9" , "Prol-G2Mphase"='#0fc082',
              "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue')

rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")


comb.brain <- JoinLayers(comb.brain)
comb.brain <- NormalizeData(comb.brain, normalization.method = "LogNormalize", scale.factor = 10000)
comb.brain <- subset(comb.brain, subset = nFeature_RNA > 500 & nFeature_RNA < 6000 &  nCount_RNA > 2000 & nCount_RNA < 30000)
comb.brain <- subset(comb.brain, subset= Cdh5>0.1 & Ptprc<0.1)
comb.brain <- NormalizeData(comb.brain, normalization.method = "LogNormalize", scale.factor = 10000)
comb.brain <- FindVariableFeatures(comb.brain, selection.method = "vst")
comb.brain <- ScaleData(comb.brain) 
comb.brain <- RunPCA(comb.brain ) # use this genes to reduce tech variability among ports of my samples
ElbowPlot(comb.brain, ndims = 50, reduction = 'pca')
Idents(comb.brain) <- 'experiment' #Variable that indicates the port of sequencing
comb.brain <- RunHarmony(comb.brain, "experiment", plot_convergence = TRUE)
a<-DimPlot(comb.brain, reduction = "pca", pt.size = 0.5, group.by = "experiment", shuffle = T )+
  ggtitle('No HARMONY')+theme(legend.position = 'bottom')
b<-DimPlot(comb.brain, reduction = "harmony", pt.size = 0.5, group.by = "experiment", shuffle = T)+
  ggtitle('HARMONY')+theme(legend.position = 'none')
cairo_pdf(filename = 'Harmony_Brain.pdf', width = 15, height = 5)
print(grid.arrange(a, b, ncol=2))
dev.off()

#1st First filter to see cell types
comb.brain <- FindNeighbors(comb.brain, dims = 1:29, reduction="harmony")
comb.brain <- FindClusters(comb.brain, resolution = 0.8, cluster.name = 'res0.8brain')
comb.brain<-RunUMAP(comb.brain, dims = 1:29,  reduction.name = "dim29brain",return.model = T, reduction = 'harmony')
#Identify markers to see contaminant clusters
brain_degs <- FindAllMarkers(comb.brain, logfc.threshold = 1, min.pct = 0.7, only.pos = T)
brain_top10 <- brain_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
#plot UMAP to see cluster distribution in space.
a<-DimPlot(comb.brain, reduction = 'dim29brain', group.by = 'res0.8brain', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.brain, var = 'res0.8brain', group.by = 'genotype.x', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.brain, features = unique(brain_top10$gene), group.by = 'res0.8brain')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- FeaturePlot(comb.brain, features = c('Pdgfrb'), reduction = 'dim29brain')&
  scale_color_gradientn(colours = rz_palette)
 mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,4,4),c(1,1,2,4,4),c(1,1,2,4,4),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d, layout_matrix=mt))
dev.off()
saveRDS(comb.brain, file='Cobined_Brain_v1.rds')

#Cluster 5 are pericytes
#Cluster 11 are lung contaminating cells
#Cluster 12 are fat cells
#Cluster 13 Liver cells
#cluster 14 are fat cells
#Cluster 16 are heart cells

Idents(comb.brain) <-'res0.8brain'
comb.brain2 <- subset(comb.brain, idents=c(5,11,12,13,14,16), invert=T)

Idents(comb.brain2)<-'genotype.x'
levels(Idents(comb.brain2)) <-c('ShortTerm_Ctrl', 'ShortTerm_KdrTomNeg', 'ShortTerm_KdrTom', 'LongTerm_Ctrl', 'LongTerm_KdrTom', 'LongTerm_KdrTom')
comb.brain2$genotype <- Idents(comb.brain2)

saveRDS(comb.brain2, file='Cobined_Brain_v2.rds')

#1st First filter to see cell types
comb.brain2 <- FindNeighbors(comb.brain2, dims = 1:29, reduction="harmony")
comb.brain2 <- FindClusters(comb.brain2, resolution = 0.8, cluster.name = 'res0.8brain')
comb.brain2<-RunUMAP(comb.brain2, dims = 1:29,  reduction.name = "dim29brain",return.model = T, reduction = 'harmony')
brain_degs <- FindAllMarkers(comb.brain2, logfc.threshold = 1, min.pct = 0.7, only.pos = T)
brain_top10 <- brain_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)
a<-DimPlot(comb.brain2, reduction = 'dim29brain', group.by = 'res0.8brain', 
           cols = Colors_1to20, label = T, label.box = T)
b<-dittoBarPlot(comb.brain2, var = 'res0.8brain', group.by = 'genotype', color.panel = Colors_1to20)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.brain2, features = unique(brain_top10$gene), group.by = 'res0.8brain')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
d <- FeaturePlot(comb.brain2, features = c('Pdgfrb'), reduction = 'dim29brain')&
  scale_color_gradientn(colours = rz_palette)
mt <- rbind(c(1,1,2,4,4), c(1,1,2,4,4),c(1,1,2,4,4),c(1,1,2,4,4),c(1,1,2,4,4),
            c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3),c(3,3,3,3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined2.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c,d, layout_matrix=mt))
dev.off()

#Cluster 10 are astrocytes 
Idents(comb.brain2) <- 'res0.8brain'
comb.brain3 <- subset(comb.brain2, ident=10, invert=T)
#Normalize the Kdr gene
comb.brain3$kdr_exon3Norm <- log((comb.brain3$Kdr_exon3*10^4/comb.brain3$nCount_RNA)+1)
comb.brain3$kdr_exon30Norm <- log((comb.brain3$Kdr_exon30*10^4/comb.brain3$nCount_RNA)+1)
#Give cluster names 
Idents(comb.brain3) <- 'res0.8brain'
levels(Idents(comb.brain3))
plots <- list()
dimensions_test <- c(20:30)
for (dim in dimensions_test){
  comb.brain3 <- FindNeighbors(comb.brain3, dims = 1:dim, reduction="harmony")
  name_red <- paste0('dim', dim, 'brain')
  comb.brain3<-RunUMAP(comb.brain3, dims = 1:dim,  reduction.name = name_red,return.model = T, reduction = 'harmony')
  plots[[dim]] <-DimPlot(comb.brain3, reduction = name_red, group.by = 'res0.8brain', 
          cols = Colors_1to20, label = T, label.box = T)
}
grid.arrange(plots[20:25], ncol=2)
#Best dim-reduction is 20

#Change cell type names
Idents(comb.brain3) <-'res0.8brain'
celltype_names <- c('ArtCap', 'Act', 'VeinCap', 'Cap', 'Arteries', 'Prol-G2Mphase', 'Veins', 'Prol-G2Mphase', 'Prol-Sphase', 'Choroid-plexus')
levels(Idents(comb.brain3)) <- celltype_names
comb.brain3$celltypes <- Idents(comb.brain3)

brain_degs <- FindAllMarkers(comb.brain3, logfc.threshold = 1, min.pct = 0.7, only.pos = T)
brain_top10 <- brain_degs %>% group_by(cluster) %>% top_n(10, avg_log2FC)

a<-DimPlot(comb.brain3, reduction = 'dim20brain', group.by = 'celltypes', 
           cols = brain_cols, label = T, label.box = T)
b<-dittoBarPlot(comb.brain3, var = 'celltypes', group.by = 'genotype', color.panel = brain_cols)+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.title = element_blank())
c<-DotPlot(comb.brain3, features = unique(brain_top10$gene), group.by = 'celltypes')&
  scale_colour_gradientn(colours = rz_palette)&
  theme(axis.text.x = element_text(angle = 90, vjust =0.5, hjust = 1, face = 'italic'))
mt <- rbind(c(1,2), c(1,2), c(3,3))
cairo_pdf(filename = 'Summary_Dimplots_Combined3.pdf', width = 20, height = 10)
print(grid.arrange(a,b,c, layout_matrix=mt))
dev.off()


comb.brain3$celltypes <- factor(comb.brain3$celltypes, levels=c( "Arteries" , 'ArtCap','Cap', 'VeinCap','Veins',
                                                                 'Act', 'Prol-Sphase', 'Prol-G2Mphase', 'Choroid-plexus'))

names(comb.brain3@reductions)[4] <- 'dim20_final'

Idents(comb.brain3) <- 'Sample'
levels(Idents(comb.brain3))<- c('Male','Female', 'Female','Male', 'Female','Female','Female')
comb.brain3$sex.x <-Idents(comb.brain3)

#Save final object
saveRDS(comb.brain3, file='Cobined_Brain_v3.rds')

