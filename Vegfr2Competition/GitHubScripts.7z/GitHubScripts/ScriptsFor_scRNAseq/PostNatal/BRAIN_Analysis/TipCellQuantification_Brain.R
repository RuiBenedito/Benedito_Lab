library(Seurat)
library(ggpubr)
library(dittoSeq)
library(dplyr)
library(dbplyr)
library(ggplot2)
library(gridExtra)
library(msigdbr)
library(fgsea)
library(harmony)
library(Matrix)
library(celldex)
library(SingleR)
library(scRNAseq)
library(SingleCellExperiment)
library(escape)
library(reshape2)
library(presto)
library(tidyverse)
library(scuttle)
library(tidyverse)
library(ggrepel)
library(dittoSeq)
library(fgsea)
library(VennDiagram)
library(cowplot)
library(escape)  
library(writexl)
library(EnhancedVolcano)
library(ggplot.multistats)
library(SCpubr)
library(ggVennDiagram)
library(Nebulosa)
library(ggbreak)


source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Fgsea_TableFgsea.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_FilterLowExpressionGenes_onlyTable.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Find_PlotGenesHeatmap_FC_Metadata.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_VolcanoPlot.R')
source('S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/3_Functions/FUNCTION_Degs_Table_PerCellType.R')
Colors_1to20 <- c(
  '0' = '#adfa36',
  '1' = "#FF6666",  # Light Red
  '2' = "#FF9966",  # Light Orange
  '3' = "#FFFF66",  # Light Yellow
  '4' = "#66FF66",  # Light Green
  '5' = "#66B3FF",  # Light Blue
  '6' = "#B366FF",  # Light Purple
  '7' = "#FF66B3",  # Light Pink
  '8' = "#FFCC66",  # Light Gold
  '9' = "#6699FF",  # Sky Blue
  '10' = "#9A66FF", # Lavender
  '11' = "#66E0A5", # Light Spring Green
  '12' = "#66D9D9", # Light Cyan
  '13' = "#F2A766", # Light Copper
  '14' = "#D88A6D", # Light Brown
  '15' = "#C266FF", # Bright Purple
  '16' = "#FFA07A", # Light Salmon
  '17' = "#7FFFD4", # Aquamarine
  '18' = "#FFD700", # Gold
  '19' = "#DC143C", # Crimson Red
  '20' = "#00CED1"  # Dark Turquoise
)
brain_cols <-c('Cap'="#FFCC66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
               'Arteries'="#ec245b","Act"="#B366FF", "Choroid-plexus" ="#e7d6f9" , "Prol-G2Mphase"='#0fc082',
               "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue')

brain_cols <-c('Cap'="#FFCC66", 'ArtCap'='#ee9db3','Veins'='#6699FF',
               'Arteries'="#ec245b","Act"="#B366FF", "Choroid-plexus" ="#e7d6f9" , "Prol-G2Mphase"='#0fc082',
               "Prol-Sphase"='#72e9c0', 'VeinCap'='lightblue')

rz_palette <- c("#DEDAD6","#FEE392","#FEC44E","#FE9929","#ED6F11","#CC4C17","#993411","#65260C")

comb.brain <- readRDS("S:/LAB_RB/LAB/Irene/PostDoc/scRNAseq/1_Kdr_POSTNATAL_CombinedAnalysis_Short240903_Long2410/1_RDS_Files/Brain_Combined/Cobined_Brain_v3.rds")

comb.brain$genotype <- droplevels(factor(comb.brain$genotype))

#Order by same levels the colours

brain_cols_ord <-c('Arteries'="#ec245b", 'ArtCap'='#ee9db3','Cap'="#FFCC66",'VeinCap'='lightblue','Veins'='#6699FF',
                   "Act"="#B366FF","Prol-Sphase"='#72e9c0', "Prol-G2Mphase"='#0fc082', "Choroid-plexus" ="#e7d6f9" )


#possible tip markers
tipcell_markers <-c("Cxcr4", "Unc5b", "Plxnd1", "Adm", "Plaur", "Kcne3", "Esm1", "Angpt2", "Aqp1", "Apln", "Dll4", "Spry4")

#Save the plot with all the markers to identify the most tip cell like

cairo_pdf(filename = 'Nebulosaplot_allTipMarkers.pdf', width = 20, height = 15)
Nebulosa::plot_density(comb.brain, features = tipcell_markers, reduction = 'dim20_final')
dev.off()

cairo_pdf(filename = 'Featureplot_TopTipGenes_PerGenotype_SameScale_2.pdf', width =8, height = 13)
do_FeaturePlot(comb.brain, features = c('Plxnd1', 'Apln'), split.by = 'genotype',reduction = 'dim20_final',
               pt.size = 0.3, ncol = 1, use_viridis = F,legend.ncol = 4, legend.width =0.5,legend.length = 5,
               border.size = 0, sequential.palette = 'Oranges')
dev.off()

#Violin plots per genotype
Idents(comb.brain)<-'genotype'
combrain_short <- subset(comb.brain, idents=c('ShortTerm_KdrTom','ShortTerm_Ctrl'))
cairo_pdf(filename = 'Violinplot_TipCellGenes_ByGenotype_Plxdn1_Apln.pdf', width =7, height = 4)
VlnPlot(subset(combrain_short, downsample= 961), group.by = 'genotype',ncol = 2, 
        features = c('Plxnd1','Apln'),
        cols = c('ShortTerm_Ctrl'='#0fc082', 'ShortTerm_KdrTom'='#FF6666'))&
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=8),
        axis.text.y = element_text(angle = 90, hjust =0.5,  face = 'italic', size=10),
        axis.title = element_blank(), legend.position = 'none', title = element_text(size=15))
dev.off()


#Add module score with the most specific tip cell markers
selection <- c('Plxnd1', 'Kcne3',  'Plaur', 'Angpt2','Apln', 'Adm')
comb.brain <- AddModuleScore(comb.brain, features = list(selection),name = 'TipCellMarkers' )
Idents(comb.brain) <- 'genotype'
#Plot violin of deletion and dotplot
df <- comb.brain@meta.data
# Group by genotype and calculate % of cells with TipCellMarkers1 > 0
th=0 #thresold defined
sum_table<-df %>%
  group_by(genotype = comb.brain$genotype) %>%
  summarise(
    total_cells = n(),
    positive_cells = sum(TipCellMarkers1 > th),
    percent_positive = 100 * positive_cells / total_cells
  )
Idents(comb.brain) <- 'genotype'
s<-paste(selection, collapse = ", ")
a<-VlnPlot(subset(comb.brain, downsample= 961), group.by = 'genotype',ncol = 1, 
           features = c('TipCellMarkers1'),
           cols = c('ShortTerm_Ctrl'='#0fc082', 'ShortTerm_KdrTom'='#FF6666'))+
  geom_text(
    data = sum_table,
    aes(x = genotype, y = 1.5, label = paste0(round(percent_positive, 1), "%")),
    inherit.aes = FALSE,
    size = 4,
    angle = 0,
    hjust = 0.5,vjust=-3
  )+ scale_y_continuous(limits = c(NA,2))+ 
  theme(axis.text.x = element_text(angle = 0, hjust =0.5,  face = 'italic', size=8),
        axis.title = element_blank(), legend.position = 'none', title = element_text(size=10))+
  ggtitle('Tip cell genes score (Postnatal Brain)', subtitle = paste0('Genes > ',th, s))

cairo_pdf(filename = 'Vlnplot_TipCellScore_Percentage_tipGenes.pdf', width = 5, height = 5)
a
dev.off()


